package com.sist.movie;

import java.util.*;
import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MovieManager {
	public ArrayList<MovieVO> movieAllData(){
		ArrayList<MovieVO> list=new ArrayList<>();
		
		try{
			ArrayList<String> link=movieLinkData();
			//
			
			
			
		}catch(Exception ex){
			System.out.println("movieAllData()"+ex.getMessage());
		}
		
		return list;
	}
	
	public ArrayList<String> movieLinkData(){
		ArrayList<String> list=new ArrayList<>();
		
		try{
			//web�� ����
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/").get();
			/*
                    <div class="box-contents">
                        <a href="/movies/detail-view/?midx=79470">
                            <strong class="title">��: ���� ���Ϸ���</strong>
                        </a>
			 * 
			 */
			Elements linkElem=doc.select("div.box-contents a");
			int j=0;
			for(int i=0;i<linkElem.size();i++){
				if(i%2==0){
					Element a_tag=linkElem.get(i);
					String href=a_tag.attr("href");
					if(!href.equals("#"))
						list.add("http://www.cgv.co.kr/"+href);
					System.out.println(href);
					j++;
					if(j>6) break;
				}
			}
			
		}catch(Exception ex){
			System.out.println("movieLinkData()"+ex.getMessage());
		}
		
		return list;
	}
}












