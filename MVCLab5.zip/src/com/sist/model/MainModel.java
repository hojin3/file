package com.sist.model;

import java.util.*;

import javax.servlet.http.HttpServletRequest;

import com.sist.controller.Controller;
import com.sist.controller.RequestMapping;

@Controller
public class MainModel {
	@RequestMapping("main.do")
	public String main_page(HttpServletRequest request){
		
		return "main/main.jsp";
	}
}









