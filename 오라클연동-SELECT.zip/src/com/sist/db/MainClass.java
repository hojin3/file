package com.sist.db;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class MainClass extends JFrame implements MouseListener,ActionListener{
	
	JLabel la;
	JTable table;
	DefaultTableModel model;
	JLabel la1;
	JComboBox box;
	JTextField tf;
	JButton b1,b2;
	
	public MainClass(){
		la=new JLabel("������",JLabel.CENTER);
		la.setFont(new Font("���� ����", Font.BOLD, 30));
		
		String[] col={"���","�̸�","����","�Ի���","�μ���ȣ"};
		String[][] row=new String[0][5];
		model=new DefaultTableModel(row,col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		la1=new JLabel("Search");
		box=new JComboBox();
		box.addItem("�̸�");
		box.addItem("����");
		box.addItem("�Ի���");
		tf=new JTextField(10);
		b1=new JButton("ã��");					
		b2=new JButton("���");
		/*
		 * <label>Search</label>
		 * <select>
		 */
		
		JPanel p=new JPanel();
		p.add(la1);
		p.add(box);
		p.add(tf);
		p.add(b1);
		p.add(b2);
		
		add("South",p);
		add("North",la);
		add("Center",js);
		
		setSize(640, 480);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		getData();
		
		table.addMouseListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
	}
	
	public void getData(){
		EmpDAO dao=new EmpDAO();
		ArrayList<EmpVO> list=dao.empAllData();
		
		for(int i=model.getRowCount()-1;i>=0;i--){
			model.removeRow(i);
		}
		
		for(EmpVO vo:list){
			String[] data={
				String.valueOf(vo.getEmpno()),
						vo.getEname(),
						vo.getJob(),
						vo.getHiredate().toString(),
				String.valueOf(vo.getDeptno())
			};
			model.addRow(data);
		}
	}
	
	public static void main(String[] args){
		try{
/*			EmpDAO dao=new EmpDAO();
			
			ArrayList<EmpVO> list=dao.empAllData();
			for(EmpVO vo:list){
				System.out.println(vo.getEmpno()+" "
						+vo.getEname()+" "
						+vo.getJob()+" "
						+vo.getHiredate().toString()+" "
						+vo.getDeptno());
			}*/
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		new MainClass();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b1){
			getFindData();
		}else if(e.getSource()==b2){
			getData();
		}
		
	}
	
	public void getFindData(){
		String ss=tf.getText();
		if(ss.length()<1){
			JOptionPane.showMessageDialog(this, "�˻�� �Է��ϼ���");
			tf.requestFocus();
			return;
		}
		int index=box.getSelectedIndex();
		String fs="";
		
		if(index==0)
			fs="ename";
		else if(index==1)
			fs="job";
		else
			fs="hiredate";
		
		EmpDAO dao=new EmpDAO();
		ArrayList<EmpVO> list=dao.empFindData(fs, ss);
		
		for(int i=model.getRowCount()-1;i>=0;i--){
			model.removeRow(i);
		}
		
		for(EmpVO vo:list){
			String[] data={
				String.valueOf(vo.getEmpno()),
				vo.getEname(),
				vo.getJob(),
				vo.getHiredate().toString(),
				String.valueOf(vo.getDeptno())
			};
			model.addRow(data);
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==table){
			if(e.getClickCount()==2){
				int row=table.getSelectedRow();
				String empno=model.getValueAt(row, 0).toString();
				//System.out.println(empno);
				
				EmpDAO dao=new EmpDAO();
				EmpVO vo=dao.empDetailData(Integer.parseInt(empno));
				String msg="���:"+vo.getEmpno()+"\n"
						+"�̸�:"+vo.getEname()+"\n"
						+"����:"+vo.getJob()+"\n"
						+"���:"+vo.getMgr()+"\n"
						+"�Ի���:"+vo.getHiredate()+"\n"
						+"�޿�:"+vo.getSal()+"\n"
						+"������:"+vo.getComm()+"\n"
						+"�μ���ȣ:"+vo.getDeptno();
				JOptionPane.showMessageDialog(this, msg);
			}
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
