package com.sist.dao;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class MemberDAO {
	private static SqlSessionFactory ssf;	//Connection
	
	static{
		ssf=CreateSqlSessionFactory.getSsf();
	}
	
	//<select id="memberIdCheck" parameterType="String" resultType="int">
	//								�Ű�����					������
	public int memberIdCheck(String id){
		SqlSession session=ssf.openSession();
		int count=session.selectOne("memberIdCheck",id);
		session.close();
		return count;
	}
	
	//<select id="memberGetPwd" resultType="Member" parameterType="String">
	public MemberVO memberGetPwd(String id){
		SqlSession session=ssf.openSession();
		MemberVO vo=session.selectOne("memberGetPwd", id);
		session.close();//��ȯ
		return vo;
	}
}










