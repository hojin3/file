package com.sist.board.model;

import javax.servlet.http.HttpServletRequest;

import com.sist.controller.Controller;
import com.sist.controller.RequestMapping;

@Controller
public class BoardModel {
	@RequestMapping("list.do")
	public String board_list(HttpServletRequest request){
		String page=request.getParameter("page");
		
		System.out.println("list.do");//
		return "";
	}
}
