package com.sist.jdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.dao.SawonDAO;
import com.sist.dao.SawonVO;

@Controller
public class SawonController {
	@Autowired
	private SawonDAO dao;
	
	@RequestMapping("sawon/list.do")
	public String sawonAllData(Model model){
		List<SawonVO> list=dao.sawonAllData();
		model.addAttribute("list", list);
		return "list";
	}
	
	@RequestMapping("sawon/insert.do")
	public String sawonInsert(){
		return "insert";
	}
	
	@RequestMapping("sawon/insert_ok.do")
	public String sawonInsertOK(SawonVO vo){
		//DB
		dao.sawonInsert(vo);
		return "redirect:/sawon/list.do";
	}
}






















