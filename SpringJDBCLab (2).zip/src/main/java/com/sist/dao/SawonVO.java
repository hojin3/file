package com.sist.dao;
/*
    sabun     NUMBER    PRIMARY KEY,
    name      VARCHAR2(20)  NOT NULL,
    job       VARCHAR2(30)  NOT NULL,
    dname     VARCHAR2(20)  NOT NULL,
    loc       VARCHAR2(20)  NOT NULL,
    sal       NUMBER * 
 */
public class SawonVO {
	private int sabun;
	private String name;
	private String job;
	private String dname;
	private String loc;
	private int sal;
	public int getSabun() {
		return sabun;
	}
	public void setSabun(int sabun) {
		this.sabun = sabun;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getDname() {
		return dname;
	}
	public void setDname(String dname) {
		this.dname = dname;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	
}














