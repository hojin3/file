package com.sist.movie;

import java.util.*;
import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MovieManager {
	public ArrayList<MovieVO> movieAllData(){
		ArrayList<MovieVO> list=new ArrayList<>();
		
		try{
			ArrayList<String> link=movieLinkData();
			int mno=1;
			String[] theater={
				"0,1,2,3,4,5",
				"1,4,6,7,8,10,12,13,14",
				"8,9,10,11,12,13,14",
				"5,6,7,8,9,10,11",
				"3,6,9,11,12,13",
				"4,5,6,7,10,11,12",
				"6,10,11,13,14"
			};
			
			int i=0;
			for(String url:link){
				Document doc=Jsoup.connect(url).get();
				/*
				    <div class="box-contents">
				        <div class="title"> 
				            <strong>��: ���� ���Ϸ���</strong>
				 * 
				 */
				Element title=doc.select("div.box-contents div.title strong").first();
				
				/*
    <div class="box-image">
        <a href="http://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79470/79470_1000.jpg" title="������ ũ�� ���� ��â" target="_blank">
            <span class="thumb-image"> 
                <img src="http://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79470/79470_185.jpg" alt="��: ���� ���Ϸ��� ������ ��â" onerror="errorImage(this)"/>
				 * 
				 */
				Element poster=doc.select("div.box-image span.thumb-image img").first();
				
				/*
    <div class="box-image">
        <a href="http://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79470/79470_1000.jpg" title="������ ũ�� ���� ��â" target="_blank">
            <span class="thumb-image"> 
                <img src="http://img.cgv.co.kr/Movie/Thumbnail/Poster/000079/79470/79470_185.jpg" alt="��: ���� ���Ϸ��� ������ ��â" onerror="errorImage(this)"/>
                <span class="ico-posterdetail">������ ũ�� ����</span>
                <span class="ico-grade grade-12"> 12�� �̻�</span>
				 */
				Element grade=doc.select("div.box-image span.thumb-image span.ico-grade").first();
				
				/*
        <div class="spec">
            <dl>
                <dt>���� :&nbsp;</dt>
                <dd>
                    
                        
                        <a href="/movies/persons/?pidx=116933">���� ��Ʈ-�ι���</a>                    
                        
                </dd>
				 */
				Element director=doc.select("div.spec dl dd a").get(0);
				Element actor=doc.select("div.spec dl dd a").get(1);
				Element regdate=doc.select("div.spec dl dd").get(4);
				Element genre=doc.select("div.spec dl dt").get(2);
				
				MovieVO vo=new MovieVO();
				vo.setMno(mno);
				vo.setLink(url);
				vo.setTitle(title.text());
				String img=poster.attr("src");
				vo.setPoster(img);
				vo.setDirector(director.text());
				vo.setActor(actor.text());
				vo.setGrade(grade.text());
				vo.setRegdate(regdate.text());
				String temp=genre.html().replace("&nbsp;", "");
				temp=temp.substring(temp.indexOf(":")+1);
				vo.setGenre(temp);
				vo.setTheater(theater[i]);
				
				list.add(vo);
				mno++;
				i++;
				System.out.println(title.text());
			}
			
			
		}catch(Exception ex){
			System.out.println("movieAllData()"+ex.getMessage());
		}
		
		return list;
	}
	
	public ArrayList<String> movieLinkData(){
		ArrayList<String> list=new ArrayList<>();
		
		try{
			//web�� ����
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/").get();
			/*
                    <div class="box-contents">
                        <a href="/movies/detail-view/?midx=79470">
                            <strong class="title">��: ���� ���Ϸ���</strong>
                        </a>
			 * 
			 */
			Elements linkElem=doc.select("div.box-contents a");
			int j=0;
			for(int i=0;i<linkElem.size();i++){
				if(i%2==0){
					Element a_tag=linkElem.get(i);
					String href=a_tag.attr("href");
					if(!href.equals("#"))
						list.add("http://www.cgv.co.kr/"+href);
					System.out.println(href);
					j++;
					if(j>6) break;
				}
			}
			
		}catch(Exception ex){
			System.out.println("movieLinkData()"+ex.getMessage());
		}
		
		return list;
	}
}












