package com.sist.model;

public class GuGuModel {
	public String guguDan(int dan){
		String result="";
		
		for(int i=1;i<=9;i++){
			result+=(dan)+"*"+i+"="+(dan*i)+"<br/>";
		}
		
		return result;
	}
}
