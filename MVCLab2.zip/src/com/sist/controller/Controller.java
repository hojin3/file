package com.sist.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sist.model.GuGuModel;

public class Controller extends HttpServlet{
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cmd=request.getParameter("cmd");
		String dan=request.getParameter("dan");
		
		if(cmd.equals("gugu")){
			GuGuModel g=new GuGuModel();
			String res=g.guguDan(Integer.parseInt(dan));
			request.setAttribute("res", res);
		}
		RequestDispatcher rd=request.getRequestDispatcher("gugudan.jsp");
		rd.forward(request, response);
	}
}


















