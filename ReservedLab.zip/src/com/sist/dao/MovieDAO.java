package com.sist.dao;

import java.sql.*;		//Connection,PrepareStatement,ResultSet
import java.util.*;		//ArrayList

public class MovieDAO {
	//���ᰴü ����
	private Connection conn;
	//���۰�ü ����
	private PreparedStatement ps;
	//����Ŭ �ּ� ����
	private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";

	
	//����̹� ���
	public MovieDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	/*
	 * �޼��� �뵵 :
	 * 	1)�Ѱ� ����� ����
	 *  2)�ݺ� ����.
	 */
	//���� ��ü ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL,"scott","tiger");
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	//���� ����
	public void disConnection(){
		try{
			if(ps!=null)ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());
		}
	}
	
	public List<MovieInfoVO> movieAllData(){
		List<MovieInfoVO> list=new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT mno,title,grade,theather_no "
					+"FROM movieInfo";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				MovieInfoVO vo=new MovieInfoVO();
				vo.setMno(rs.getInt(1));
				vo.setTitle(rs.getString(2));
				vo.setGrade(rs.getString(3));
				vo.setTheather_no(rs.getString(4));
				list.add(vo);
			}
			rs.close();
			
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			disConnection();
		}		
		return list;
	}
	
	public List<TheaterInfoVO> theaterAllData(){
		List<TheaterInfoVO> list=new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT tno,tname,tloc,dateno "
					+"FROM theaterInfo";
			ps=conn.prepareStatement(sql);
			
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				TheaterInfoVO vo=new TheaterInfoVO();
				vo.setTno(rs.getInt(1));
				vo.setTname(rs.getString(2));
				vo.setTloc(rs.getString(3));
				vo.setDateno(rs.getString(4));
				list.add(vo);
			}
			rs.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			disConnection();
		}
		
		return list;
	}
}












