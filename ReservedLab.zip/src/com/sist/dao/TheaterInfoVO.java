package com.sist.dao;

/*
   tno        NUMBER,
   tname      VARCHAR2(100),
   tloc       VARCHAR2(100),
   dateno     VARCHAR2(100) * 
 */
public class TheaterInfoVO {
	private int tno;
	private String tname;
	private String tloc;
	private String dateno;
	public int getTno() {
		return tno;
	}
	public void setTno(int tno) {
		this.tno = tno;
	}
	public String getTname() {
		return tname;
	}
	public void setTname(String tname) {
		this.tname = tname;
	}
	public String getTloc() {
		return tloc;
	}
	public void setTloc(String tloc) {
		this.tloc = tloc;
	}
	public String getDateno() {
		return dateno;
	}
	public void setDateno(String dateno) {
		this.dateno = dateno;
	}
	
}


















