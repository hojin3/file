package com.sist.dao;
/*
  mno       NUMBER,
  title     VARCHAR2(100),
  actor     VARCHAR2(1000),
  director  VARCHAR2(500),
  genre     VARCHAR2(300),
  poster    VARCHAR2(1000),
  grade     VARCHAR2(100),
  story     CLOB,
  theather_no   VARCHAR2(100) * 
 */
public class MovieInfoVO {
	private int mno;
	private String title;
	private String actor;
	private String director;
	private String grade;
	private String regdate;
	private String sposter;
	private String story;
	private String theather_no;
	public int getMno() {
		return mno;
	}
	public void setMno(int mno) {
		this.mno = mno;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getActor() {
		return actor;
	}
	public void setActor(String actor) {
		this.actor = actor;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getRegdate() {
		return regdate;
	}
	public void setRegdate(String regdate) {
		this.regdate = regdate;
	}
	public String getSposter() {
		return sposter;
	}
	public void setSposter(String sposter) {
		this.sposter = sposter;
	}
	public String getStory() {
		return story;
	}
	public void setStory(String story) {
		this.story = story;
	}
	public String getTheather_no() {
		return theather_no;
	}
	public void setTheather_no(String theather_no) {
		this.theather_no = theather_no;
	}
	
	
}












