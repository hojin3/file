package com.sist.mgr;
import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;



public class MovieCGVManager {
	
	public List<MovieVO> getMovieData(){
		List<MovieVO> mv=new ArrayList<>();
		
		try{
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/?ft=0").get();
			Elements titleElem=doc.select("div.box-contents strong.title");  //
			Elements imageElem=doc.select("div.box-image a span.thumb-image img");
			Elements gradeElem=doc.select("div.box-image a span.thumb-image span");
			Elements rankElem=doc.select("div.box-image strong.rank");
			
			Elements percentElem=
					doc.select("div.box-contents div.score strong.percent span");
			Elements likeElem=
					doc.select("div.box-contents span.like span.count strong i");//
			Elements starElem=doc.select("div.box-contents span.percent");
			Elements dayElem=doc.select("div.box-contents span.txt-info strong");
			
			for(int i=0;i<7;i++){
				Element telem=titleElem.get(i);
				Element pelem=percentElem.get(i);
				Element delem=dayElem.get(i);
				Element lelem=likeElem.get(i);
				Element selem=starElem.get(i);
				Element ielem=imageElem.get(i);
				String img=ielem.attr("src");
				Element relem=rankElem.get(i);
				Element gelem=gradeElem.get(i);
				
				MovieVO d=new MovieVO();
				d.setTitle(telem.text());
				d.setReserve(Double.parseDouble(
						pelem.text().substring(0, pelem.text().lastIndexOf('%'))));
				d.setPoster(img);
				d.setLike(Integer.parseInt(lelem.text().replace(",", "")));
				d.setRegdate(delem.text().substring(
						0, delem.text().lastIndexOf("����")));
				d.setRank(Integer.parseInt(relem.text().substring(3)));
				d.setGrade(gelem.text());
				mv.add(d);
			}
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return mv;
	}
}


















