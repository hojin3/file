package com.sist.dao.food;
/*
  no          NUMBER        PRIMARY KEY ,
  category    VARCHAR2(1000) NOT NULL,
  subject     VARCHAR2(1000) NOT NULL,
  poster      VARCHAR2(1000) NOT NULL,
  link        VARCHAR2(1000) NOT NULL * 
 */
public class FoodCategoryVO {
	private int no;
	private String category;
	private String subject;
	private String poster;
	private String link;
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getPoster() {
		return poster;
	}
	public void setPoster(String poster) {
		this.poster = poster;
	}
	public String getLink() {
		return link;
	}
	public void setLink(String link) {
		this.link = link;
	}
	
	
}






















