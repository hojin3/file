package com.sist.dao.food;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.SelectKey;

public interface FoodMapper {
	
	@SelectKey(keyProperty="no",resultType=int.class,
		before=true,
		statement="SELECT NVL(MAX(no)+1,1) as no FROM list_category")
	@Insert("INSERT INTO list_category VALUES("
			+"#{no},#{category},#{subject},"
			+"#{poster}, #{link})") 
	//	  returnType				parameterType
	public void list_categoryInsert(FoodCategoryVO vo);
	
	@Delete("DELETE FROM list_category")
	public void list_categoryDelete();
}



























