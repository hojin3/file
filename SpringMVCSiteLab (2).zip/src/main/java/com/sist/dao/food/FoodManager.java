package com.sist.dao.food;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

/*
        <div class="top_list_slide">
              <ul class="list-toplist-slider" style="width: 531px;">
                    <li>
                      <img class="center-croping"
                           src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/l8vogdo7ogj-h_f2.jpg?fit=around|600:400&amp;crop=600:400;*,*&amp;output-format=jpg&amp;output-quality=80"
                           alt="�ʵ��Ը� ���� ����Ʈ 15�� ����"
                           onerror="this.src='https://mp-seoul-image-production-s3.mangoplate.com/web/resources/kssf5eveeva_xlmy.jpg?fit=around|*:*&amp;crop=*:*;*,*&amp;output-format=jpg&amp;output-quality=80'"
                      />


                      <a href="/top_lists/890_choding"
                         onclick="common_ga('PG_MAIN','CLICK_LIST');">
                        <figure class="ls-item">
                          <figcaption class="info">
                            <div class="info_inner_wrap">
                              <span class="title">�ʵ��Ը� ���� ����Ʈ 15��</span>

                              <p class="desc">"�� ���� ���� �� �� �����ž�"</p> * 
 */
@Component
public class FoodManager {
	public static void main(String[] args){
		FoodManager fm=new FoodManager();
		fm.foodCategoryData();
	}
	
	public List<FoodCategoryVO> foodCategoryData(){
		List<FoodCategoryVO> list=
				new ArrayList<FoodCategoryVO>();
		
		try{
			Document doc=Jsoup.connect("http://mangoplate.com/").get();
			Elements category=
					doc.select("div.top_list_slide figcaption.info span.title");
			Elements subject=
					doc.select("div.top_list_slide figcaption.info p.desc");
			Elements poster=doc.select("div.top_list_slide img");
			Elements link=doc.select("div.top_list_slide a");
			
			for(int i=0;i<9;i++){
				Element c=category.get(i);
				Element s=subject.get(i);
				Element p=poster.get(i);
				String img=p.attr("src");
				Element l=link.get(i);
				String href=l.attr("href");
				System.out.println(c.text()+" "
						+s.text()+" "
						+img+" "
						+href);
				
				FoodCategoryVO vo=new FoodCategoryVO();
				vo.setCategory(c.text());
				vo.setSubject(s.text());
				vo.setPoster(img);
				vo.setLink("http://mangoplate.com/"+href);
				list.add(vo);
			}
					
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		return list;
	}
}






























