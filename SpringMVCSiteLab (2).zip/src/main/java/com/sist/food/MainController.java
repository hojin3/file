package com.sist.food;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sist.dao.food.FoodCategoryVO;
import com.sist.dao.food.FoodDAO;
import com.sist.dao.food.FoodManager;

@Controller
public class MainController {
	@Autowired
	private FoodManager fm;
	@Autowired
	private FoodDAO dao;
	
	@RequestMapping("food_main/main.do")
	public String food_main(Model model){
		dao.list_categoryDelete();
		List<FoodCategoryVO> list= fm.foodCategoryData();
		
		for(FoodCategoryVO vo:list){
			String subject=vo.getSubject().replace("\"", "");
			String link=vo.getLink().replace("&", "^");
			vo.setSubject(subject);
			vo.setLink(link);
			
			dao.list_categoryInsert(vo);
		}
		
		return "food_main/main";
	}
	
}





















