package com.sist.multiboard;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;

import com.sist.dao.DataBoardDAO;
import com.sist.dao.DataBoardVO;

@Controller
public class DataBoardController {
	@Autowired
	private DataBoardDAO dao;
	
	@RequestMapping("databoard/list.do")
	public String databoard_list(String page,Model model){
		if(page==null)
			page="1";
		
		int curpage=Integer.parseInt(page);
		
		Map map=new HashMap();
		int rowSize=10;
		int start=(curpage*rowSize)-(rowSize-1);
		int end=curpage*rowSize;
		
		map.put("start", start);
		map.put("end", end);
		
		List<DataBoardVO> list=dao.databoardListData(map);
		int totalpage=dao.databoardTotalPage();
		
		model.addAttribute("list", list);
		model.addAttribute("curpage", curpage);
		model.addAttribute("totalpage", totalpage);
		
		return "databoard/list";
	}
	
	@RequestMapping("databoard/insert.do")
	public String databoard_insert(){
		return "databoard/insert";
	}
	
	@RequestMapping("databoard/insert_ok.do")
	public String databoard_insert_ok(DataBoardVO uploadForm)
	throws Exception{
		
		List<MultipartFile> list=uploadForm.getFiles();
		String temp="";
		String temp1="";
		if(list !=null && list.size()>0){
			for(MultipartFile mf:list){
				String fn=mf.getOriginalFilename();
				String ext=fn.substring(fn.lastIndexOf('.')+1);
				String save=fn.substring(0, fn.lastIndexOf('.'))
						+System.currentTimeMillis()+"."+ext;
				File file=new File("C:\\download\\"+save);
				mf.transferTo(file);
				temp+=save+",";
				temp1+=file.length()+",";
			}
			uploadForm.setFilename(temp.substring(0, temp.lastIndexOf(',')));
			uploadForm.setFilesize(temp1.substring(0, temp1.lastIndexOf(',')));
			uploadForm.setFilecount(list.size());
		}else{
			uploadForm.setFilename("");
			uploadForm.setFilesize("");
			uploadForm.setFilecount(0);
		}
		dao.databoardInsert(uploadForm);
		return "redirect:/databoard/list.do";
	}
	
	@RequestMapping("/databoard/content.do")
	public String databoard_content(int no,Model model){
		DataBoardVO vo=dao.databoardContentData(no);
		
		if(vo.getFilecount()!=0){
			StringTokenizer st=
					new StringTokenizer(vo.getFilename(), ",");
			List<String> list=new ArrayList<String>();
			while(st.hasMoreTokens()){
				list.add(st.nextToken());
			}
			vo.setNameList(list);
		}
		model.addAttribute("vo", vo);
		
		return "databoard/content";
	}
	
	@RequestMapping("databoard/download.do")
	public void databoard_download(String fn,HttpServletResponse response){
		try{
			response.setHeader("Content-Disposition", 
					"attachment;filename="+URLEncoder.encode(fn,"EUC-KR"));
			File file=new File("c:\\download\\"+fn);
			response.setContentLength((int)file.length());
			BufferedInputStream bis=
					new BufferedInputStream(new FileInputStream(file));
			BufferedOutputStream bos=
					new BufferedOutputStream(response.getOutputStream());
			int i=0;
			byte[] buffer=new byte[1024];
			while((i=bis.read(buffer,0,1024))!=-1){
				bos.write(buffer, 0, i);
			}
			bis.close();
			bos.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}	
	}
	
	@RequestMapping("databoard/delete.do")
	public String databoardDelete(int no,Model model){
		model.addAttribute("no", no);
		return "databoard/delete";
	}
	@RequestMapping("databoard/delete_ok.do")
	public String databoardDeleteOk(int no,String pwd,Model model){
		DataBoardVO vo=dao.databoardDeleteData(no);
		
		boolean bCheck=false;
		if(pwd.equals(vo.getPwd())){
			bCheck=true;
			if(vo.getFilecount()!=0){
				StringTokenizer st=
						new StringTokenizer(vo.getFilename(), ",");
				while(st.hasMoreTokens()){
					File file=new File("c:\\download\\"+st.nextToken());
					file.delete();
				}
			}//end if
			dao.databoardDelete(no);
		}else{
			bCheck=false;
		}
		model.addAttribute("bCheck", bCheck);
		return "databoard/delete_ok";
	}
}















