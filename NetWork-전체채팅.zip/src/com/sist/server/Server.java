package com.sist.server;

import java.net.*;
import java.io.*;
import java.util.*;

public class Server implements Runnable{
	ServerSocket ss;	
	Vector<Client> waitVc=new Vector<Client>();
	
	public Server(){
		try{
			ss=new ServerSocket(3355);
			System.out.println("Server Start...");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	public static void main(String[] args){
		Server server=new Server();
		new Thread(server).start();
	}
	
	@Override
	public void run() {
		try{
			while(true){
				Socket s=ss.accept();
				Client client =new Client(s);
				waitVc.addElement(client);
				client.start();
			}
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
	}
	
	
	class Client extends Thread{
		//������ ����
		Socket s;
		BufferedReader in;
		OutputStream out;
		
		public Client(Socket s){
			//Ŭ���̾�Ʈ�� ����
			try{
				this.s=s;
				in=new BufferedReader(new InputStreamReader(s.getInputStream()));
				out=s.getOutputStream();
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
		
		//��� ó�� ===> JSP
		@Override
		public void run() {
			try{
				while(true){
					String msg=in.readLine();
					messageAll(msg);
					
				}
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
		
		public synchronized void messageAll(String msg){
			try{
				for(Client client:waitVc){
					client.messageTo(msg);
				}
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
		
		public synchronized void messageTo(String msg){
			try{
				out.write((msg+"\n").getBytes());
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
	}

}














