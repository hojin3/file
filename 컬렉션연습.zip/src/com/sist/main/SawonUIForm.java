package com.sist.main;

import javax.swing.JFrame;

public class SawonUIForm extends JFrame{
	
}
