package com.sist.main;

import javax.swing.*;

public class SawonUIForm extends JFrame{
	JLabel la1,la2,la3,la4,la5;
	JTextField tf,tf2;
	JComboBox box1,box2,box3;
	JButton b1,b2;
	
	public SawonUIForm(){
		la1=new JLabel("�̸�");
		la2=new JLabel("�μ�");
		la3=new JLabel("�ٹ���");
		la4=new JLabel("����");
		la5=new JLabel("����");
		
		tf=new JTextField();
		box1=new JComboBox();
		box1.addItem("������");
		box1.addItem("��ȹ��");
		box1.addItem("�ѹ���");
		box1.addItem("���ߺ�");
		box1.addItem("�����");
		
		box2=new JComboBox();
		box2.addItem("����");
		box2.addItem("�λ�");
		box2.addItem("���");
		box2.addItem("����");
		box2.addItem("�ؿ�");
		
		box3=new JComboBox();
		box3.addItem("���");
		box3.addItem("�븮");
		box3.addItem("����");
		box3.addItem("����");
		box3.addItem("����");
		
		tf2=new JTextField();
		
		b1=new JButton("���");
		b2=new JButton("���");
		
		setLayout(null);
		la1.setBounds(10, 15, 50, 30);
		tf.setBounds(65, 15, 150, 30);
		
		la2.setBounds(10, 50, 50, 30);
		box1.setBounds(65, 50, 150, 30);
		
		la3.setBounds(10, 85, 50, 30);
		box2.setBounds(65, 85, 150, 30);
		
		la4.setBounds(10, 120, 50, 30);
		box3.setBounds(65, 120, 150, 30);
		
		la5.setBounds(10, 155, 50, 30);
		tf2.setBounds(65, 155, 150, 30);
		
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		p.setBounds(10, 190, 205, 35);
		
		add(la1);add(tf);
		add(la2);add(box1);
		add(la3);add(box2);
		add(la4);add(box3);
		add(la5);add(tf2);
		add(p);
		
	}
	
	
}












