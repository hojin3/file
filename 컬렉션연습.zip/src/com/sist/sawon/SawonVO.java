package com.sist.sawon;
//ĸ��ȭ ==> �����Ͱ��� Ŭ����

public class SawonVO {
	private int sabun;			//���
	private String name;		//�̸�
	private String dept;		//�μ���
	private String loc;			//�ٹ���
	private String hiredate;	//�Ի���
	private String job;			//����
	private int pay;			//����
	
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public int getSabun() {
		return sabun;
	}
	public void setSabun(int sabun) {
		this.sabun = sabun;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLoc() {
		return loc;
	}
	public void setLoc(String loc) {
		this.loc = loc;
	}
	public String getHiredate() {
		return hiredate;
	}
	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	
	public SawonVO(){
		
	}
	public SawonVO(int sabun, String name, String dept, String loc, String hiredate, String job, int pay) {
		super();
		this.sabun = sabun;
		this.name = name;
		this.dept = dept;
		this.loc = loc;
		this.hiredate = hiredate;
		this.job = job;
		this.pay = pay;
	}
	

	
	
}

















