package com.sist.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
/*
 * 		list.jsp
 * 		=========
 * 		��û: <a href="content.do?no=10">����</a>
 * 			
 * 		content.do ==> DispatcherServlet (service())
 * 						1)Ŭ������ ã�´� => ContentModel
 * 						===============================
 * 							handlerRequest()ȣ��
 * 							-dao����
 * 
 */
import com.sist.dao.*;
public class ContentModel implements Model{

	@Override
	public String handlerRequest(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		//content.do?no
		String no=request.getParameter("no");
		DataBoardVO vo=DataBoardDAO.databoardContentData(Integer.parseInt(no));
		request.setAttribute("vo", vo);
		
		return "board/content.jsp";
	}

}










