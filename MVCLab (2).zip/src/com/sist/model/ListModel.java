package com.sist.model;

import java.util.HashMap;
import java.util.Map;
import java.util.*;
import com.sist.dao.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ListModel implements Model {

	@Override
	public String handlerRequest(HttpServletRequest request, HttpServletResponse response) throws Throwable {
		String strPage=request.getParameter("page");
		if(strPage==null)
			strPage="1";
		System.out.println(strPage);
		
		int curpage=Integer.parseInt(strPage);
		int rowSize=10;
		int start=(rowSize*curpage)-(rowSize-1);
		int end=rowSize*curpage;
		
		Map map=new HashMap();
		map.put("start", start);		// #{start}
		map.put("end", end);
		
		List<DataBoardVO> list=DataBoardDAO.databoardListData(map);
		request.setAttribute("list", list);
		
		return "board/list.jsp";
	}

}






