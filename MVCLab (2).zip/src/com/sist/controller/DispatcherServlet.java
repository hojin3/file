package com.sist.controller;

import java.io.*;
import java.util.*;
import com.sist.model.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.*;
import org.w3c.dom.*;

/*
 * 	1)�ļ��⸦ ���� ==> ������ ���� ���
 * 				  
 * 		DocumentBuilderFactory => ML�� ������ ����.
 * 								HTML,XML,WML,HDML,VRML
 * 		DocumentBuilder : �ļ���
 *  2)�ļ� => �޸𸮿� dom Ʈ�����·� ����.
 *  	DocumentBuilder.parse(���ϸ�)
 *  3)�ڹٿ��� �ʿ��� �����͸� ���´�.
 *  	Element
 */

public class DispatcherServlet extends HttpServlet{
	private Map<String,Model> clsMap=new HashMap<String, Model>();
	@Override
	public void init(ServletConfig config) throws ServletException {
		//���ϸ� �б�
		String path=config.getInitParameter("xmlPath");
		System.out.println(path);
		
		try{
			DocumentBuilderFactory dbf=
					DocumentBuilderFactory.newInstance();
			DocumentBuilder db=dbf.newDocumentBuilder();
			Document doc=db.parse(new File(path));
			
			Element root=doc.getDocumentElement();
			//root=beans
			
			NodeList list=root.getElementsByTagName("bean");
			
			for(int i=0;i<list.getLength();i++){
				Element bean=(Element) list.item(i);
				String id=bean.getAttribute("id");
				System.out.println(id);
				
				String cls=bean.getAttribute("class");
				System.out.println(cls);
				
				Class clsName=Class.forName(cls);
				
				Model obj=(Model) clsName.newInstance();
				clsMap.put(id, obj);
				
			}						
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
	}
	
	@Override
	protected void service(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		try{
			
			//������� ��û�� ���� ó���� �� �ִ� Ŭ����(��)�� ã�´�.
			//list.do => DispatcherServelt => service() ȣ��
			String cmd=request.getRequestURI();
			//http://localhost:8080/MVCLab/list.do
			//====================================   URL
			//                     ===============	 URI
			//					   =======			 contextPath
			cmd=cmd.substring(request.getContextPath().length()+1, 
								cmd.lastIndexOf('.'));
			Model model=clsMap.get(cmd);
			
			String jsp=model.handlerRequest(request, response);
			System.out.println("jsp="+jsp);
			
			//forward => request ����
			String temp=jsp.substring(jsp.lastIndexOf(".")+1);
			//board/list.do
			//return "list" => forward
			//return "redirect:list.do"
			if(temp.equals("do")){
				response.sendRedirect(jsp);
			}else{
				RequestDispatcher rd=request.getRequestDispatcher(jsp);
				rd.forward(request, response);
			}
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}


















