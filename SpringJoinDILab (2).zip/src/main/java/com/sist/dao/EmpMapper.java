package com.sist.dao;

import java.util.List;

import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;

public interface EmpMapper {
	@Results({
/*		@Result(property="empno",column="empno"),
		//setEmpno(rs.getInt("empno"))
		@Result(property="ename",column="ename"),
		@Result(property="job",column="job"),
		@Result(property="hiredate",column="hiredate"),
		@Result(property="sal",column="sal"),*/
		@Result(property="dvo.deptno",column="deptno"),
		//getDvo().setDeptno(rs.getInt("deptno")
		@Result(property="dvo.dname",column="dname"),
		@Result(property="dvo.loc",column="loc")
	})
	@Select("SELECT empno,ename,job,hiredate,sal,"
			+"dept.deptno,dname,loc "
			+"FROM emp,dept "
			+"WHERE emp.deptno=dept.deptno")
	public List<EmpVO> empdeptAllData();
	
	
	
	@Select("SELECT empno,ename,job,hiredate,sal,"
			+"dept.deptno,dname,loc "
			+"FROM emp,dept "
			+"WHERE emp.deptno=dept.deptno "
			+"AND empno=#{empno}")
	public EmpVO empdeptFindData(int empno);
}


















