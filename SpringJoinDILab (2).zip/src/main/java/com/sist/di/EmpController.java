package com.sist.di;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.portlet.bind.annotation.RenderMapping;

import com.sist.dao.EmpDAO;
import com.sist.dao.EmpVO;

@Controller
public class EmpController {
	@Autowired
	private EmpDAO dao;
	@RequestMapping("emp/list.do")
	public String empAllData(Model model){
		List<EmpVO> list=dao.empdeptAllData();
		model.addAttribute("list", list);
		return "emp/list";
	}
	
	@RequestMapping("emp/find.do")
	public String empFindData(int empno,Model model){
		EmpVO vo=dao.empdeptFindData(empno);
		model.addAttribute("vo", vo);
		return "emp/find";
	}
}






















