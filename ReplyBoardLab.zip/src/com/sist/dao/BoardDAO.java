package com.sist.dao;

import java.util.*;
import java.sql.*;

/*
 * 			*group_id	: ������ ���� �����ִ� �÷�(�亯 �׷�=�亯�� �����ִ� ��ȣ)
 * 			 group_tab	: �� ��° �亯���� ��Ÿ���� �÷�
 * 			 group_step : ���� ���� ������ ������ �ִ� �÷�
 * 
 * 								group_id			group_tab			group_step
 * 			���ο� ��(50) 				50					0					0
 * 				|
 * 				|
 * 				--�亯1				50					1					1
 * 					|
 * 					|
 * 					--�亯1�� �亯1		50					2					2
 * 						|
 * 						|
 * 						--�亯1�� �亯1�亯	50				3					3
 * 					
 * 				|
 * 				--�亯2				50					1					3=>4
 * 					|
 * 					|
 * 					--�亯2�� �亯		50					2					4=>5
 * 				
 */

// POJO => �Ϲ� Ŭ����
// JDBC ==> DBCP ==> ORM


public class BoardDAO {
	private Connection conn;
	private PreparedStatement ps;
	private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
	
	//����̹� ���
	public BoardDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//����Ŭ ����
	public void disConnection(){
		try{
			if(ps!=null)ps.close();
			if(conn!=null)conn.close();
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//����Ŭ ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//���ó��-����Ʈ
	public List<BoardVO> boardListData(int page){
		ArrayList<BoardVO> list=new ArrayList<>();
		
		try{
			getConnection();
			String sql="SELECT no,subject,name,regdate,hit,group_tab "
					+"FROM replyBoard "
					+"ORDER BY group_id DESC,group_step ASC";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			int i=0;
			int j=0;
			int pagecnt=(page*10)-10;
			/*
			 * 		13 	=> 0~9,		10~12
			 * 		1page		2page 		3page
			 * 		  0			  10		  20		
			 * 		  9			  19		  29
			 */
			while(rs.next()){
				if(i<10 && j>=pagecnt){
					BoardVO vo=new BoardVO();
					vo.setNo(rs.getInt(1));
					vo.setSubject(rs.getString(2));
					vo.setName(rs.getString(3));
					vo.setRegdate(rs.getDate(4));
					vo.setHit(rs.getInt(5));
					vo.setGroup_tab(rs.getInt(6));
					list.add(vo);
					i++;
				}
				j++;
			}
			
			
		}catch(Exception ex){
			System.out.println("boardListData()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		
		return list;
	}
	
	public int boardTotalPage(){
		int total=0;
		
		try{
			getConnection();
			String sql="SELECT CEIL(COUNT(*)/10) FROM replyBoard";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();
			
		}catch(Exception ex){
			System.out.println("boardTotalPage()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return total;
	}
	
	//��ü �Խñ� ����
	public int boardRowCount(){
		int total=0;
		
		try{
			getConnection();
			String sql="SELECT COUNT(*) FROM replyBoard";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();	
			
		}catch(Exception ex){
			System.out.println("boardRowCount()"+ex.getMessage());
		}finally{
			disConnection();
		}
		
		return total;
	}
}




























