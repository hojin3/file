package com.sist.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

// SpringWebLab_replyBoard/board/list.do

@Controller
public class BoardController {
	@Autowired
	private BoardDAO dao;
	
	@RequestMapping("board/list.do")
	public String board_list(Model model,String page){
		if(page==null)
			page="1";
		int curpage=Integer.parseInt(page);
		int rowSize=10;
		int start=(curpage*rowSize)-(rowSize-1);
		int end=curpage*rowSize;
		
		Map map=new HashMap();
		map.put("start", start);
		map.put("end", end);
		List<BoardVO> list=dao.boardListData(map);
		
		int totalPage=dao.boardTotalPage();
		
		model.addAttribute("curpage", curpage);
		model.addAttribute("totalPage",totalPage);
		model.addAttribute("list",list);
		
		return "list";
		
	}
	
	@RequestMapping("board/content.do")
	public String board_content(int no,Model model){
		BoardVO vo=dao.boardContentData(no);
		model.addAttribute("vo", vo);
		return "content";
	}
	
	@RequestMapping("board/insert.do")
	public String board_insert(){
		return "insert";
	}
	@RequestMapping("board/insert_ok.do")
	public String board_insert_ok(BoardVO vo){
		dao.boardInsert(vo);
		return "redirect:/board/list.do";
	}
	
	@RequestMapping("board/update.do")
	public String board_update(int no,Model model){
		BoardVO vo=dao.boardUpdateData(no);
		model.addAttribute("vo", vo);
		return "update";
	}
	
	@RequestMapping("board/update_ok.do")
	@ResponseBody
	public String board_update_ok(BoardVO vo){
		String msg="";
		boolean bCheck=dao.boardUpdate(vo);
		if(bCheck==true){
			msg="<script>"
				+"location.href=\"content.do?no="+vo.getNo()+"\";"
				+"</script>";
		}else{
			msg="<script>"
				+"alert(\"PassWord Fail..\");"
				+"history.back();"	
				+"</script>";
		}
		return msg;
	}
	
	@RequestMapping("board/reply.do")
	public String board_reply(Model model,int no){
		model.addAttribute("no", no);
		return "reply";
	}
	@RequestMapping("board/reply_ok.do")
	public String board_reply_ok(BoardVO vo,int pno){
		BoardVO pvo=dao.boardParentData(pno);
		dao.boardStepIncrement(pvo);
		
		vo.setGroup_id(pvo.getGroup_id());
		vo.setGroup_step(pvo.getGroup_step()+1);
		vo.setGroup_tab(pvo.getGroup_tab()+1);
		vo.setRoot(pno);
		
		dao.boardReplyInsert(vo);
		dao.boardDepthIncreament(pno);
		return "redirect:/board/list.do";
	}
	
	@RequestMapping("board/delete.do")
	public String board_delete(int no,Model model){
		model.addAttribute("no", no);
		return "delete";
	}
	@RequestMapping("board/delete_ok.do")
	@ResponseBody
	public String board_delete_ok(int no,String pwd){
		String msg="";
		boolean bCheck=dao.boardDelete(no, pwd);
		if(bCheck==true){
			msg="<script>"
				+"location.href=\"list.do\";"
				+"</script>";
		}else{
			msg="<script>"
				+"alert(\"PassWord Fail..\");"
				+"history.back();"	
				+"</script>";
		}
		return msg;
	}
}
















