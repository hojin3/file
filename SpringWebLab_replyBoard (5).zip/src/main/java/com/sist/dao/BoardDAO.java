package com.sist.dao;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BoardDAO {
	@Autowired
	private BoardMapper mapper;
	
	public List<BoardVO> boardListData(Map map){
		return mapper.boardListData(map);
	}
	
	public int boardTotalPage(){
		return mapper.boardTotalPage();
	}
	
	public BoardVO boardContentData(int no){
		mapper.boardHitIncrement(no);
		return mapper.boardContentData(no);
	}
	
	public void boardInsert(BoardVO vo){
		mapper.boardInsert(vo);
	}
	
	public BoardVO boardUpdateData(int no){
		return mapper.boardContentData(no);
	}
	
	public boolean boardUpdate(BoardVO vo){
		boolean bCheck=false;
		
		String db_pwd=mapper.boardGetPwd(vo.getNo());
		if(db_pwd.equals(vo.getPwd())){
			bCheck=true;
			mapper.boardUpdate(vo);
		}
		return bCheck;
	}
	
	public BoardVO boardParentData(int no){
		return mapper.boardParentData(no);
	}
	
	public void boardStepIncrement(BoardVO vo){
		mapper.boardStepIncrement(vo);
	}
	
	public void boardReplyInsert(BoardVO vo){
		mapper.boardReplyInsert(vo);
	}
	
	public void boardDepthIncreament(int no){
		mapper.boardDepthIncreament(no);
	}
	
	//����
	public boolean boardDelete(int no,String pwd){
		boolean bCheck=false;
		String db_pwd=mapper.boardGetPwd(no);
		
		if(db_pwd.equals(pwd)){
			bCheck=true;
			BoardVO vo=mapper.boardDeleteData(no);
			
			if(vo.getDepth()==0){
				mapper.boardDelete(no);
			}else{
				mapper.boardDataChange(no);
			}
			mapper.boardDepthDecrement(no);
		}
		
		return bCheck;
	}
}












