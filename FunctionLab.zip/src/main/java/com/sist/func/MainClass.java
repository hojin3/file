package com.sist.func;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MainClass {
	public static void main(String[] args){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
			Connection conn=DriverManager.getConnection(url, "scott", "tiger");
			String sql="SELECT DISTINCT deptno,pkg_emp.empCount(deptno),"
					+ "pkg_emp.empAvg(deptno),pkg_emp.empSum(deptno) "
						+"FROM emp";
			PreparedStatement ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			
			while(rs.next()){
				System.out.println(rs.getInt(1)+" "
						+rs.getInt(2)+" "
						+rs.getDouble(3)+" "
						+rs.getInt(4));
			}
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
}





















