package com.sist.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;

public interface EmpMapper {
	
	@Select("SELECT empno,ename,job,hiredate,sal,"
			+"dept.deptno,dname,loc "
			+"FROM emp,dept "
			+"WHERE emp.deptno=dept.deptno")
	public List<EmpVO> empdeptAllData();
}


















