package com.client;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class WaitRoom extends JPanel{
	JTable table;				//��� ���
	DefaultTableModel model;	//������ ����
	JButton b1,b2,b3;
	JTextPane tp;
	JComboBox box;
	JTextField tf;
	//
	
	public WaitRoom(){
		
	}
}

















