package com.client;

import java.awt.*;
import javax.swing.*;

public class Login extends JPanel{
	//�⺭ ����
	JLabel la1,la2,la3;
	JTextField tf1,tf2;
	JRadioButton rb1,rb2;
	JButton b1,b2;
	Image back;
	
	//������(��� ������ ���� �ʱ�ȭ)
	public Login(){
		back=Toolkit.getDefaultToolkit().getImage("c:\\image\\back.jpg");
		la1=new JLabel("ID");
		la2=new JLabel("�̸�");
		la3=new JLabel("����");
		tf1=new JTextField();
		tf2=new JTextField();
		rb1=new JRadioButton("����");
		rb2=new JRadioButton("����");
		b1=new JButton("�α���");
		b2=new JButton("���");
		
		setLayout(null);
		la1.setBounds(350, 280, 40, 30);
		tf1.setBounds(395, 280, 150, 30);
		
		la2.setBounds(350, 315, 40, 30);
		tf2.setBounds(395, 315, 150, 30);
		
		la3.setBounds(350, 350, 40, 30);
		rb1.setBounds(395, 350, 70, 30);
		rb2.setBounds(470, 350, 70, 30);
		rb1.setOpaque(false);
		rb2.setOpaque(false);
		
		//������ư�� �׷�
		ButtonGroup bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		rb1.setSelected(true);
		
		JPanel p=new JPanel();
		p.setOpaque(false);
		p.add(b1);
		p.add(b2);
		p.setBounds(350, 390, 190, 35);
		
		add(la1);add(tf1);
		add(la2);add(tf2);
		add(la3);add(rb1);add(rb2);
		add(p);
		
	}
	
	//�̹��� ���
	@Override
	protected void paintComponent(Graphics g) {
		g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
	}
}














