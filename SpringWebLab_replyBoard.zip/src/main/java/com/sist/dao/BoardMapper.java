package com.sist.dao;

import java.util.*;

import org.apache.ibatis.annotations.Select;

public interface BoardMapper {
	@Select("SELECT no,subject,name,regdate,hit,group_tab,num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab,rownum as num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab "
			+"FROM replyBoard ORDER BY group_id DESC,group_step ASC))"
			+"WHERE num BETWEEN #{start} AND #{end}")
	public List<BoardVO> boardListData(Map map);
			//resultType				parameterType
	
	@Select("SELECT CEIL(COUNT(*)/10) FROM replyBoard")
	public int boardTotalPage();
}












