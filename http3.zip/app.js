/**
 * http://usejsdoc.org/
 */
var fs=require('fs');
var pathUtil=require('path');

//업로드된 파일 경로
var uploadDir= __dirname + '/upload';
//이미지 파일 경로
var imageDir= __dirname + '/image';

var http=require('http');

//multiple file upload 모듈
var formidable=require('formidable');

//업로드된 데이터 목록
var paintList=[];

var server=http.createServer(function(req,res){
	//루트 경로로 요청
	if(req.url == '/' && req.method.toLowerCase() =='get'){
		showList(res);

	//<img> 태그로 이용해서 이미지 요청 (이미지 파일 선택하기)
	}else if(req.method.toLowerCase()=='get' && req.url.indexOf('/image')==0){
		var path= __dirname+req.url;
		res.writeHead(200,{'Content-Type':'image/jpeg'});
		fs.createReadStream(path).pipe(res);
		
	
	//이미지 업로드 요청	
	}else if(req.method.toLowerCase()== 'post'){
		addNewPaint(req, res);
	}
});

function showList(res){
	res.writeHeader(200,{'content-type':'text/html'});
	
	var body='<html>';
	body+='<head><meta charset="UTF-8"></head>';
	body+='<body>';
	body+='<h3>Favorite Paint</h3>';
	
	body+='<ul>';
	paintList.forEach(function(item,index){
		body+='<li>';
		if(item.image){
			body += '<img src="' +item.image+ '" style="height:100pt"></img>';
		}
		body+=item.title;
		body+='</li>';
	});
	body+='</ul>'
		
	body+='<form action="." enctype="multipart/form-data" method="post">' +
		  '<div><label>작품 이름: </label><input type="text" name="title"></div>' +
		  '<div><label>작품 이미지:</label><input type="file" name="image" value="작품 파일 선택"></div>' +
		  '<input type="submit" value="upload">' +
		  '</form>';
	body+='</body></html>';
	
	res.end(body);
}

server.listen(3000,function(){
	console.log('Server is running on 3000');
});


function addNewPaint(req,res){
	var form=formidable.IncomingForm();   //새로운 IncomingForm 생성
	form.uploadDir=uploadDir;		//파일 업로드 경로
	
	form.parse(req,function(err,fields,files){
		var title=fields.title;
		var image=files.image;
		
		var date=new Date();
		var newImageName='image_'+date.getHours()+date.getMinutes()+date.getSeconds();
		var ext=pathUtil.parse(image.name).ext;
		//업로드된 이미지 저장위치 및 파일이름
		var newPath=__dirname+'/image/'+newImageName+ext;
		
		fs.renameSync(image.path, newPath);
		
		var url='image/'+newImageName+ext;
		
		var info={
				title:title,
				image:url
		}
		paintList.push(info);
		
		res.statusCode=302;
		res.setHeader('Location', '.');
		res.end('Success');
		
	});
}














