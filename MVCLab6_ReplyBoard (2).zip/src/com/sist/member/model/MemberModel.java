package com.sist.member.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.sist.controller.Controller;
import com.sist.controller.RequestMapping;
import com.sist.dao.MemberDAO;
import com.sist.dao.MemberVO;

@Controller
public class MemberModel {
	@RequestMapping("login.do")
	public String loginForm(HttpServletRequest request){
		return "main/login.jsp";
	}
	
	@RequestMapping("login_ok.do")
	public String isLogin(HttpServletRequest request){
		String id=request.getParameter("id");
		String pwd=request.getParameter("pwd");
		System.out.println(id+"|"+pwd);
		
		MemberDAO dao=new MemberDAO();
		String result="";
		int count=dao.memberIdCheck(id);
		
		if(count==0){
			result="noid";
		}else{
			MemberVO vo=dao.memberGetPwd(id);
			if(pwd.equals(vo.getPwd())){
				result="ok";
				HttpSession session=request.getSession();
				session.setAttribute("id", id);
				session.setAttribute("name", vo.getName());
				session.setAttribute("gender", vo.getGender());
			}else{
				result="nopwd";
			}
		}
		request.setAttribute("result", result);
		return "main/login_ok.jsp";
	}
}












