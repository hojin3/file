package com.sist.board.model;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import com.sist.controller.Controller;
import com.sist.controller.RequestMapping;
import com.sist.dao.BoardDAO;
import com.sist.dao.BoardVO;

import java.util.*;
import com.sist.dao.*;

@Controller
public class BoardModel {
	@RequestMapping("list.do")
	public String board_list(HttpServletRequest request){
		String page=request.getParameter("page");
		if(page==null)
			page="1";
		int curpage=Integer.parseInt(page);
		
		int rowSize=10;
		int start=(curpage*rowSize)-(rowSize-1);
		int end=curpage*rowSize;
		
		Map map=new HashMap();
		map.put("start", start);
		map.put("end", end);
		
		BoardDAO dao=new BoardDAO();
		List<BoardVO> list=dao.boardListData(map);
		request.setAttribute("list", list);
		
		return "main/list.jsp";
	}
}










