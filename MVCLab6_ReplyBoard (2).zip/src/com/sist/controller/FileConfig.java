package com.sist.controller;
import java.util.*;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import java.io.*;

public class FileConfig {
	List<String> list=new ArrayList<>();
	
	public FileConfig(String path){
		try{
			//�ļ��� ����
			SAXParserFactory spf=SAXParserFactory.newInstance();
			SAXParser sp=spf.newSAXParser();
			HandlerMapping hm=new HandlerMapping();
			sp.parse(new File(path), hm);
			list=hm.list;
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public List<String> componentScan(){
		List<String> fList=new ArrayList<>();
		
		try{
			String path="C:\\webProjects\\webLab2\\MVCLab6_ReplyBoard\\src\\";
			for(String pack:list){
				path=path+pack.replace(".", "\\");
				
				File dir=new File(path);
				File[] files=dir.listFiles();
				for(File f:files){
					if(f.isFile()){
						String name=f.getName();	//MainModel.java
						String ext=name.substring(name.lastIndexOf(".")+1);	//java
						if(ext.equals("java")){
							String temp=pack+"."+name.substring(0, name.lastIndexOf("."));
							fList.add(temp);
						}
					}
				}
				path="C:\\webProjects\\webLab2\\MVCLab6_ReplyBoard\\src\\";
			}
			
			
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return fList;
	}
}


















