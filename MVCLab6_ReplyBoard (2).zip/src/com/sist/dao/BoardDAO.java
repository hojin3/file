package com.sist.dao;

import java.util.*;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
public class BoardDAO {
	private static SqlSessionFactory ssf;
	
	public BoardDAO(){
		ssf=CreateSqlSessionFactory.getSsf();
	}
	
	//<select id="boardListData"  resultType="Board" parameterType="java.util.Map">
	public List<BoardVO> boardListData(Map map){
		SqlSession session=ssf.openSession();
		List<BoardVO> list=session.selectList("boardListData", map);
		session.close();
		return list;
	}
}















