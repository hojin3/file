package com.sist.dao;

import javax.sql.DataSource;

import org.mybatis.spring.SqlSessionFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Component("ssf")
public class MySqlSessionFactoryBean extends SqlSessionFactoryBean{

	@Autowired
	public void initDao(DataSource ds){
		setDataSource(ds);
	}
	
	public MySqlSessionFactoryBean() {
		try{
			Resource res=new ClassPathResource("Config.xml");
			setConfigLocation(res);
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
}








