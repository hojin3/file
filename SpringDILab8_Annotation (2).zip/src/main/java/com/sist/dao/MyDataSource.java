package com.sist.dao;

import org.apache.commons.dbcp.BasicDataSource;
import org.springframework.stereotype.Component;

@Component("ds")
public class MyDataSource extends BasicDataSource{
	public MyDataSource(){
		setDriverClassName("oracle.jdbc.driver.OracleDriver");
		setUrl("jdbc:oracle:thin:@211.238.142.212:1521:ORCL");
		setUsername("scott");
		setPassword("tiger");
	}
}
