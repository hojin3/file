package com.sist.main;

import javax.swing.*;

public class EmpDetailPanel extends JFrame{
	JLabel[] la=new JLabel[10];
	JTextField[] tf=new JTextField[10];
	JButton b1,b2,b3;
	String[] label={
		"���","�̸�","����","���","�Ի���",
		"�޿�","������","�μ���","�ٹ���","���"
	};
	
	public EmpDetailPanel(){
		setLayout(null);
		for(int i=0;i<10;i++){
			la[i]=new JLabel(label[i]);
			la[i].setBounds(10, 15+(i*35), 50, 30);
			add(la[i]);
		}
		
		for(int i=0;i<10;i++){
			tf[i]=new JTextField();
			tf[i].setBounds(65, 15+(i*35), 150, 30);
			add(tf[i]);
			tf[i].setEnabled(false);
		}
		
		b1=new JButton("����");
		b2=new JButton("����");
		b3=new JButton("���");
		
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		p.add(b3);
		p.setBounds(10, 15+(10*35), 200, 35);
		add(p);
		
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	}
	
	public static void main(String[] args){
		new EmpDetailPanel();
	}
	
}

















