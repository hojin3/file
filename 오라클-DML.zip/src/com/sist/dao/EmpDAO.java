package com.sist.dao;

import java.util.*;
import java.sql.*;

public class EmpDAO {
	private Connection conn;
	private PreparedStatement ps;
	private final String URL="";
	
	public EmpDAO(){
		
	}
	
	public void getConnection(){
		
	}
	
	public void disConnection(){
		
	}
	
	public ArrayList<EmpVO> empListData(int page){
		ArrayList<EmpVO> list=new ArrayList<>();
		
		return list;
	}
	
	public int empTotalPage(){
		int total=0;
		
		return total;
	}
	
	//�󼼺��� ==> ����
	public EmpVO empDetailData(int empno){
		EmpVO vo=new EmpVO();
		
		try{
			getConnection();
			String sql="SELECT empno,ename,job,mgr,"
					+"hiredate,sal,comm,dname,loc,"
					+"grade "
					+"FROM emp,dept,salgrade "
					+"WHERE emp.deptno=dept.deptno "
					+"AND sal BETWEEN losal AND hisal "
					+"AND empno=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, empno);
			ResultSet rs=ps.executeQuery();
			rs.next();
			//�� ���
			vo.setEmpno(rs.getInt(1));
			vo.setEname(rs.getString(2));
			vo.setJob(rs.getString(3));
			vo.setMgr(rs.getInt(4));
			vo.setHiredate(rs.getDate(5));
			vo.setSal(rs.getInt(6));
			vo.setComm(rs.getInt(7));
			vo.getDvo().setDname(rs.getString(8));
			vo.getDvo().setLoc(rs.getString(9));
			vo.getSvo().setGrade(rs.getInt(10));
			rs.close();
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return vo;
	}
	
	//��� ==> INSERT
	public void empInsert(EmpVO vo){
		
	}
	
	//���-����
	public ArrayList<EmpVO> empGetJob(){
		ArrayList<EmpVO> list=new ArrayList<>();
		
		return list;
	}
	
	//���-���
	public ArrayList<Integer> empGetMgr(){
		ArrayList<Integer> list=new ArrayList<>();
		
		return list;
	}
	
	//����
	public void empDelete(int empno){
		
	}
	
	//ã��
	public ArrayList<EmpVO> empFindData(String fs,String ss){
		ArrayList<EmpVO> list=new ArrayList<>();
		
		
		return list;
	}
	
	//�����ϱ�-������ �ҷ�����
	public EmpVO empUpdateData(int empno){
		EmpVO vo=new EmpVO();
		
		return vo;
	}
	
	//�����ϱ�-������ �ݿ��ϱ�
	public void empUpdate(EmpVO vo){
		
	}
	
	
	
}
















