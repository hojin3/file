package com.sist.movie;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.sist.client.MovieRankView;

import javax.swing.*;

public class MovieMain extends JPanel implements MouseListener{
	
	JLabel la1,la2;
	JTable table1;
	DefaultTableModel model1;
	JLabel[] poster=new JLabel[7];
	
	MovieCGVManager mgr=new MovieCGVManager();
	MovieRankView mrv=new MovieRankView();		//�Ǳ��
	
	//ä�� ��� �κ�
	JTextArea ta;
	JTextField tf;
	JComboBox box;
	
	public MovieMain() {
		MovieVO[] mv=mgr.getMovieData();
		
		//������
		
		setLayout(null);
		
		mrv.setBounds(10, 320, 350, 330);
		//
		//
		
		add(mrv);
	}
	
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
