package com.sist.movie;

import org.jsoup.*;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class MovieRankDAO {
	public MovieRankVO[] getRankData(){
		MovieRankVO[] mrv=new MovieRankVO[10];

		try{
			Document doc=
				Jsoup.connect("http://movie.naver.com/movie/sdb/rank/rmovie.nhn").get();
			Elements title=doc.select("td.title div.tit3");
			Elements id=doc.select("td.range");		//0
			Elements type=doc.select("td.ac img");	//-	
			
			int j=1;
			for(int i=0;i<mrv.length;i++){
				Element telem=title.get(i);
				Element ielem=id.get(i);
				Element typeElem=type.get(j);
				String img=typeElem.attr("src");
				String temp=img.substring(img.lastIndexOf("/")+1);	//icon_na_1.gif
				System.out.println(temp+ielem.text());
				
				MovieRankVO vo=new MovieRankVO();
				vo.setTitle(telem.text());
				vo.setIdcrement(Integer.parseInt(ielem.text()));	//������
				
				if(temp.equals("icon_na_1.gif")){
					vo.setType(0);
				}else if(temp.equals("icon_down_1.gif")){
					vo.setType(1);
				}else{
					vo.setType(2);
				}
				
				mrv[i]=vo;
				j+=2;
			}
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		
		return mrv;
		
		
	}
}
