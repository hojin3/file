package com.sist.movie;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/*
   <div class="box-image">
        <a href="#" title="��â" class="movie_player_popup" data-gallery-idx="141559">
            <span class="thumb-image">
                <  src="http://img.cgv.co.kr/Movie/Thumbnail/Trailer/79423/79423141559_1024.jpg" 
                alt="[�� ŷ]���� ������-�� ŷ" style="width:126px;height:71px;" />
                <span class="ico-play">���󺸱�</span>
            </span>
        </a>
    </div>
    <div class="box-contents">
        <a href="#" title="��â" class="movie_player_popup" data-gallery-idx="141559">
            <strong class="title">�� ŷ</strong>
        </a>
        <span class="txt-info">
        <em class="genre">����,&nbsp;���</em>
 * 
 */
public class MovieCGVManager {
	public MovieVO[] getMovieData(){
		MovieVO[] mv=new MovieVO[7];
		try{
			Document doc=Jsoup.connect("http://www.cgv.co.kr/movies/?ft=0").get();
			Elements pelem=doc.select("div.box-image span.thumb-image img");
			Elements telem=doc.select("div.box-contents strong.title");
			for(int i=0;i<mv.length;i++){
				Element poster=pelem.get(i);
				String pos=poster.attr("src");
				Element title=telem.get(i);
				
				MovieVO vo=new MovieVO();
				vo.setTitle(title.text());
				vo.setPoster(pos);
				mv[i]=vo;
			}
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		return mv;
	}
}
