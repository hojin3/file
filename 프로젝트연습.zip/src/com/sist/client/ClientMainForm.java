package com.sist.client;

import javax.swing.*;

import com.sist.movie.MovieMain;

import java.awt.event.*;
import java.awt.*;

public class ClientMainForm extends JFrame implements ActionListener{

	CardLayout card=new CardLayout();
	MovieMain movieMain=new MovieMain();
	LoginForm login=new LoginForm();
	
	public ClientMainForm() {
		setLayout(card);
		setTitle("SIST Movie Center");
		add("LOGIN", login);
		add("MOVIE", movieMain);
		setSize(900, 695);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		login.b1.addActionListener(this);
		login.b2.addActionListener(this);
		
	}
	
	public static void main(String[] args){
		try{
			UIManager.setLookAndFeel("com.jtattoo.plaf.hifi.HiFiLookAndFeel");
			JFrame.setDefaultLookAndFeelDecorated(true);
		}catch(Exception ex){
			System.out.println();
		}
		
		ClientMainForm m=new ClientMainForm();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==login.b1){
			card.show(getContentPane(), "MOVIE");
		}else if(e.getSource()==login.b2){
			dispose();
			System.exit(0);
		}
		
	}

}

















