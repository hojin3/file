package com.sist.client;

import com.sist.movie.MovieCGVManager;
import com.sist.movie.MovieVO;

import javax.swing.*;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

import java.awt.*;
import java.net.URL;


public class LoginForm extends JPanel implements Runnable{
	JLabel panLabel;
	JLabel la1,la2,la3;
	JTextField tf1,tf2;
	JRadioButton rb1,rb2;
	JButton b1,b2;
	MovieCGVManager mgr=new MovieCGVManager();
	MovieVO[] mv=new MovieVO[7];
	int index=0;
	Image back;
	
	public LoginForm() {
		
		try{
			back=Toolkit.getDefaultToolkit().getImage("C:\\image\\background.jpg");
			mv=mgr.getMovieData();
			URL url=new URL(mv[index].getPoster());	
			
			panLabel=new JLabel(new ImageIcon
					(getImageChange(new ImageIcon(url), 500, 300)));
			
			TitledBorder tb=
					new TitledBorder(new LineBorder(Color.BLACK));
			
			panLabel.setBorder(tb);
			
			///
			la1=new JLabel("���̵�");
			la2=new JLabel("��ȭ��");
			la3=new JLabel("�� ��");
			tf1=new JTextField();
			tf2=new JTextField();
			rb1=new JRadioButton("����");
			rb2=new JRadioButton("����");
			rb1.setOpaque(false);
			rb2.setOpaque(false);
			ButtonGroup bg=new ButtonGroup();
			bg.add(rb1);
			bg.add(rb2);
			rb1.setSelected(true);
			
			b1=new JButton("�α���");
			b2=new JButton("���");
			
			setLayout(null);
			
			panLabel.setBounds(200, 15, 500, 300);
			la1.setBounds(350, 400, 60, 30);
			tf1.setBounds(415, 400, 150, 30);
			la2.setBounds(350, 435, 150, 30);
			tf2.setBounds(415, 435, 150, 30);
			la3.setBounds(350, 470, 60, 30);
			rb1.setBounds(415, 470, 70, 30);
			rb2.setBounds(490, 470, 70, 30);
			
			JPanel p=new JPanel();
			p.add(b1);
			p.add(b2);
			p.setBounds(350, 510, 210, 35);
			///
			add(panLabel);
			add(la1);add(tf1);
			add(la2);add(tf2);
			add(la3);add(rb1);add(rb2);
			add(p);
			
			new Thread(this).start();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		
	}
	
	public Image getImageChange(ImageIcon img,int width,int height){
		Image i=img.getImage();
		Image c=i.getScaledInstance(width, height, Image.SCALE_SMOOTH);
		return c;
	}
	
	
	@Override
	public void run() {
		try{
			while(true){
				URL url=new URL(mv[index].getPoster());
				panLabel.setIcon(
						new ImageIcon(getImageChange(new ImageIcon(url), 500, 300)));
				index++;
				Thread.sleep(1000);
				if(index>6)
					index=0;
			}
			
		}catch(Exception ex){
			System.out.println();
		}
		
	}
	
	@Override
	protected void paintComponent(Graphics g) {
		g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
	}

}







