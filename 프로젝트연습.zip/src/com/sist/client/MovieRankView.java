package com.sist.client;

import javax.swing.JPanel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import com.sist.movie.MovieRankDAO;
import com.sist.movie.MovieRankVO;

import javax.swing.*;
import java.awt.*;

public class MovieRankView extends JPanel{
	JTabbedPane tp;
	JLabel la1,la2,la3;
	JTable table1,table2,table3;
	DefaultTableModel model1,model2,model3;
	
	public MovieRankView(){
		tp=new JTabbedPane();
		
		String[] col1={"��ȭ��","������"};
		String[][] row1=new String[0][2];
		model1=new DefaultTableModel(row1,col1);
		
		table1=new JTable(model1);
		table1.getTableHeader().setBackground(Color.pink);
		table1.setRowHeight(27);
		JScrollPane js1=new JScrollPane(table1);
		
		//
		//
		
		tp.addTab("��ȭ ����", js1);
		//
		//
		setTableWidth();
		getData();
		setLayout(new BorderLayout());
		add(tp);
	}
	
	public void setTableWidth(){
		TableColumn column=null;
		DefaultTableCellRenderer r=new DefaultTableCellRenderer();
		
		for(int i=0;i<2;i++){
			column=table1.getColumnModel().getColumn(i);
			if(i==0){
				column.setPreferredWidth(200);
			}else{
				column.setPreferredWidth(50);
				r.setHorizontalAlignment(JLabel.CENTER);
			}
		}
		
		column.setCellRenderer(r);
		
		//
		//
		
	}
	
	public void getData(){
		MovieRankDAO m=new MovieRankDAO();
		MovieRankVO[] mr=m.getRankData();
		
		String img="";
		
		for(MovieRankVO vo:mr){
			if(vo.getType()==0)
				img="-";
			else if(vo.getType()==1)
				img="��";
			else
				img="��";
			
			String[] temp={vo.getTitle(),img+" "
								+String.valueOf(vo.getIdcrement())};
			model1.addRow(temp);				
	  }
		
	
	 //
		
		
	//	
	}
	//
	
	//
}












