package com.sist.dao;

import java.util.*;
import java.sql.*;

import org.springframework.stereotype.Repository;

import oracle.jdbc.internal.OracleTypes;


@Repository
public class BoardDAO {
	private Connection conn;
	private CallableStatement cs;
	private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
	
	public BoardDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	public void disConnection(){
		try{
			if(cs!=null)cs.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	public List<BoardVO> boardListData(int page){
		List<BoardVO> list=new ArrayList<BoardVO>();
		
		try{
			getConnection();
			String sql="{CALL boardListData(?,?,?)}";
			int rowSize=10;
			int start=(rowSize*page)-(rowSize-1);
			int end=rowSize*page;
			cs=conn.prepareCall(sql);
			cs.setInt(1, start);
			cs.setInt(2, end);
			cs.registerOutParameter(3, OracleTypes.CURSOR);
			
			//����
			cs.executeUpdate();
			
			ResultSet rs=(ResultSet) cs.getObject(3);
			while(rs.next()){
				BoardVO vo=new BoardVO();
				vo.setNo(rs.getInt(1));
				vo.setSubject(rs.getString(2));
				vo.setName(rs.getString(3));
				vo.setRegdate(rs.getDate(4));
				vo.setHit(rs.getInt(5));
				list.add(vo);
			}
			cs.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return list;
	}
	
	public int boardTotalPage(){
		int total=0;
		
		try{
			getConnection();
			String sql="{CALL boardTotalPage(?)}";
			cs=conn.prepareCall(sql);
			cs.registerOutParameter(1, OracleTypes.INTEGER);
			
			cs.executeUpdate();
			total=cs.getInt(1);
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return total;
	}
	
	public BoardVO boardContentData(int no){
		BoardVO vo=new BoardVO();
		
		try{
			getConnection();
			String sql="{CALL boardContentData(?,?)}";
			
			cs=conn.prepareCall(sql);
			cs.setInt(1, no);
			cs.registerOutParameter(2, OracleTypes.CURSOR);
			
			//����
			cs.executeUpdate();
			ResultSet rs=(ResultSet) cs.getObject(2);
			rs.next();
			
			vo.setNo(rs.getInt(1));
			vo.setName(rs.getString(2));
			vo.setSubject(rs.getString(3));
			vo.setContent(rs.getString(4));
			vo.setRegdate(rs.getDate(5));
			vo.setHit(rs.getInt(6));
			
			rs.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return vo;
	}
	
	public void boardInsert(BoardVO vo){
		try{
			getConnection();
			String sql="{CALL boardInsert(?,?,?,?)}";
			cs=conn.prepareCall(sql);
			cs.setString(1, vo.getName());
			cs.setString(2, vo.getSubject());
			cs.setString(3, vo.getContent());
			cs.setString(4, vo.getPwd());
			cs.executeUpdate();
			
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			disConnection();
		}
	}
}




















