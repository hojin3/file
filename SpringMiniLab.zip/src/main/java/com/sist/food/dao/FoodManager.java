package com.sist.food.dao;

public class FoodManager {

}
