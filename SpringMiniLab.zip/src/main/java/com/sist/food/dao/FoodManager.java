package com.sist.food.dao;

import java.util.*;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Component;

@Component
public class FoodManager {
	public static void main(String[] args){
		FoodManager f=new FoodManager();
		f.foodCategoryData();
	}
	
	public List<FoodCategoryVO> foodCategoryData(){
		List<FoodCategoryVO> list=new ArrayList<FoodCategoryVO>();
		
		try{
			Document doc=Jsoup.connect("https://www.mangoplate.com/").get();
			/*
    	<section class="module popular_top_list_wrap">
      		<div class="module_title_wrap">			 * 
      
		<div class="info_inner_wrap">
              <span class="title">��� ���� ����Ʈ 20��</span>
			 */
			Elements title=
				doc.select("section.popular_top_list_wrap div.info_inner_wrap span.title");
			
			/*
<div class="top_list_slide">
              <ul class="list-toplist-slider" style="width: 531px;">
                    <li>
                      <img class="center-croping"			 * 
			 */
			
			Elements link=doc.select("ul.list-toplist-slider li a");
			Elements poster=doc.select("ul.list-toplist-slider li img");
			for(int i=0;i<title.size();i++){
				Element telem=title.get(i);
				Element pelem=poster.get(i);
				Element lelem=link.get(i);
				
				String l=lelem.attr("href");
				String img=pelem.attr("src");
				
				System.out.println(telem.text());
				System.out.println(img);
				System.out.println(l);
				
				FoodCategoryVO vo=new FoodCategoryVO();
				vo.setTitle(telem.text());
				vo.setPoster(img);
				vo.setLink("https://www.mangoplate.com/"+l);
				list.add(vo);
			}
			
			
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
		
		return list;
		
	}
}














