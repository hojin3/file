package com.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.Model;

//Controller �۾�
public class DispatcherServlet extends HttpServlet{
	private WebApplicationContext wc;
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		String path=config.getServletContext().getRealPath("/WEB-INF/applicationContext.xml");
		wc=new WebApplicationContext(path);
	}
	
	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try{
			//��ûȮ��(�ּҰ� �б�) 
			String cmd=request.getRequestURI();
			//board_list
			cmd=cmd.substring(request.getContextPath().length()+1, cmd.lastIndexOf('.'));
			
			//Model Ŭ���� ������.
			Model model=wc.getBean(cmd);
			System.out.println("model :" +model);
			
			String jsp=model.handlerRequest(request, response);
			String temp=jsp.substring(jsp.lastIndexOf('.')+1);
			
			if(temp.startsWith("do")){
				response.sendRedirect(jsp);
			}else{
				RequestDispatcher rd=request.getRequestDispatcher(jsp);
				rd.forward(request, response);
			}
			
		}catch(Exception ex){
			System.out.println("service()"+ex.getMessage());
		}
	}
}










