package com.board.model;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.common.Model;

public class BoardContentModel implements Model{

	@Override
	public String handlerRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String rPage=request.getParameter("rPage");
		int type=0;
		if(rPage==null){
			rPage="1";
			type=1;
		}
		int rcurpage=Integer.parseInt(rPage);
		String strNo=request.getParameter("b_no");
		String strPage=request.getParameter("page");
				
		//
		//
		
		
				
		return "board/detail.jsp";
	}

}















