package com.board.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.board.dao.BoardDAO;
import com.board.dao.BoardDTO;
import com.common.Model;

public class BoardListModel implements Model{

	@Override
	public String handlerRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
		
		/* �Խ��� ����Ʈ ���*/
		String strPage=request.getParameter("page");
		if(strPage==null){
			strPage="1";
		}
		int curPage=Integer.parseInt(strPage);
		int rowSize=10;
		
		//Map�� ����
		int start=(curPage*rowSize)-(rowSize-1);
		int end=curPage*rowSize;
		
		Map map=new HashMap();
		map.put("start", start);
		map.put("end", end);
		
		List<BoardDTO> list=BoardDAO.boardListData(map);
		for(BoardDTO d : list){
			d.setReplyCount(BoardDAO.boardReplyCount(d.getB_no()));
		}
		int totalpage=BoardDAO.boardTotalPage();
		
		request.setAttribute("today", 
				new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
		request.setAttribute("list", list);
		
		request.setAttribute("curpage", curPage);
		request.setAttribute("totalpage", totalpage);
		
		request.setAttribute("jsp", "../board/list.jsp");
			
		return "board/list.jsp";
	}

}











