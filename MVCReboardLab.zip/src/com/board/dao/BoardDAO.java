package com.board.dao;

import java.io.Reader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class BoardDAO {
	private static SqlSessionFactory ssf;
	static{
		try{
			Reader reader=Resources.getResourceAsReader("Config.xml");
			ssf=new SqlSessionFactoryBuilder().build(reader);
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//�����Ͱ�������(�Խ��� ����Ʈ)
	public static List<BoardDTO> boardListData(Map map){
		List<BoardDTO> list=new ArrayList<>();
		SqlSession session=null;
		
		try{
			session=ssf.openSession();
			list=session.selectList("boardListData", map);
			
			System.out.println("start: " +map.get("start"));
			System.out.println("end: " +map.get("end"));
			System.out.println("������: " +list.size());
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			if(session !=null)
				session.close();
		}
		
		return list;
	}
	
	//�� ������
	public static int boardTotalPage(){
		int total=0;
		SqlSession session=null;
		
		try{
			session=ssf.openSession();
			int count=session.selectOne("boardRowCount");
			total=(int)(Math.ceil(count/10.0));
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			if(session !=null)
				session.close();
		}				
		return total;
	}
	
	//����� �Խ���-��� ��
	public static int boardReplyCount(int b_no){
		SqlSession session=ssf.openSession();
		int count=session.selectOne("boardReplyCount", b_no);
		session.close();
		return count;
	}
	
	//�󼼺���
	public static BoardDTO boardContentData(int b_no, int type){
		SqlSession session=null;
		BoardDTO d=new BoardDTO();
		
		try{
			//��ȸ�� ����
			session=ssf.openSession(true);
			if(type==1){
				session.update("boardHitIncrement",b_no);	
			}
			//���뺸��
			d=session.selectOne("boardContentData", b_no);
			System.out.println(d.getB_id());
		}catch(Exception ex){
			ex.printStackTrace();
		}finally{
			if(session !=null)
				session.close();
		}
		
		
		return d;
	}
}














