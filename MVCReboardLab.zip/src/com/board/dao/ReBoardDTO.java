package com.board.dao;

import java.util.Date;

/*
 *  rw_no       NUMBER      PRIMARY KEY,            -- ��۹�ȣ(pk)
    rw_order    NUMBER,                             -- ������ȣ
    rw_content  VARCHAR2(200)   NOT NULL,          -- ����
    rw_id       VARCHAR2(20),                       --�ۼ���
    rw_date     DATE  NOT NULL,                     --�����
    rw_delete   CHAR(2),                            --��������
    rw_bno      NUMBER  REFERENCES ReBoard(b_no)    --�׷��ȣ
 */
public class ReBoardDTO {
	private int rw_no;
	private int rw_order;
	private String rw_content;
	private String rw_id;
	private Date rw_date;
	private String rw_delete;
	private int rw_bno;
	private String dbday;
	private int group_tab;
	private int group_step;
	private int group_id;
	private int depth;
	private int root;
	public int getRw_no() {
		return rw_no;
	}
	public void setRw_no(int rw_no) {
		this.rw_no = rw_no;
	}
	public int getRw_order() {
		return rw_order;
	}
	public void setRw_order(int rw_order) {
		this.rw_order = rw_order;
	}
	public String getRw_content() {
		return rw_content;
	}
	public void setRw_content(String rw_content) {
		this.rw_content = rw_content;
	}
	public String getRw_id() {
		return rw_id;
	}
	public void setRw_id(String rw_id) {
		this.rw_id = rw_id;
	}
	public Date getRw_date() {
		return rw_date;
	}
	public void setRw_date(Date rw_date) {
		this.rw_date = rw_date;
	}
	public String getRw_delete() {
		return rw_delete;
	}
	public void setRw_delete(String rw_delete) {
		this.rw_delete = rw_delete;
	}
	public int getRw_bno() {
		return rw_bno;
	}
	public void setRw_bno(int rw_bno) {
		this.rw_bno = rw_bno;
	}
	public String getDbday() {
		return dbday;
	}
	public void setDbday(String dbday) {
		this.dbday = dbday;
	}
	public int getGroup_tab() {
		return group_tab;
	}
	public void setGroup_tab(int group_tab) {
		this.group_tab = group_tab;
	}
	public int getGroup_step() {
		return group_step;
	}
	public void setGroup_step(int group_step) {
		this.group_step = group_step;
	}
	public int getGroup_id() {
		return group_id;
	}
	public void setGroup_id(int group_id) {
		this.group_id = group_id;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public int getRoot() {
		return root;
	}
	public void setRoot(int root) {
		this.root = root;
	}
	
	
}
















