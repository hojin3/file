package com.sist.spring;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import java.lang.reflect.Method;
import java.util.*;

public class ClassPathXmlApplicationContext extends DefaultHandler{
	private Map clsMap=new HashMap();
	private Class clsName;
	private Object obj;
	
	
	@Override
	public void startElement(String uri, String localName, 
			String qName, Attributes attributes) throws SAXException {
		try{
			if(qName.equals("bean")){
				String id=attributes.getValue("id");
				String cls=attributes.getValue("class");
				String m=attributes.getValue("init-method");
				clsName=Class.forName(cls);		//class �����б�
				obj=clsName.newInstance();		//�޸� �Ҵ� ==> ���÷���
				clsMap.put(id, obj);
				
				Method[] methods=clsName.getDeclaredMethods();
				for(Method mm:methods){
					if(mm.getName().equals(m)){
						mm.invoke(obj, null);
					}
				}
			}
			
			if(qName.equals("property")){
				String name=attributes.getValue("name");
				String value=attributes.getValue("value");
				Method[] method=clsName.getDeclaredMethods();
				for(Method m:method){
					if(m.getName().equalsIgnoreCase("set"+name)){
						m.invoke(obj, value);
					}
				}
			}
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	public Map getClsMap(){
		return clsMap;
	}
}
















