package com.sist.di2;

import com.sist.spring.ApplicationContext;

public class MainClass {
	public static void main(String[] args){
		ApplicationContext app=
				new ApplicationContext("src/main/java/app.xml");
		Member m= (Member) app.getBean("mem");
		System.out.println("ID: " +m.getId());
		System.out.println("Name: " +m.getName());
		System.out.println("gender: " +m.getGender());
	}
}










