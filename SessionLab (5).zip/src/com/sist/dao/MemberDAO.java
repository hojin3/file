package com.sist.dao;

import java.util.*;
import java.sql.*;

public class MemberDAO {
	/*
	 * 		1)�������/Ŭ��������
	 * 			�Ϲݺ���(int/double),Ŭ����,�迭
	 * 		2)����������
	 * 			private < default < protected < public
	 * 		3)���� : ���(IS-a), ����(Has-a)
	 * 		4)����,�߰� : ������
	 * 		5)������
	 * 		6)�������̽�
	 * 		7)����ó��
	 */
		private Connection conn;
		private PreparedStatement ps;
		private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
		private static MemberDAO dao;
		
		public MemberDAO(){
			try{
				Class.forName("oracle.jdbc.driver.OracleDriver");
				//Ŭ���� ���� �б�			
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
		
		//�̱���
		public static MemberDAO newInstance(){
			if(dao==null)
				dao=new MemberDAO();
			return dao;
		}
		
		//����
		public void getConnection(){
			try{
				conn=DriverManager.getConnection(URL, "scott", "tiger");
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
		
		//����
		public void disConnection(){
			try{
				if(ps!=null) ps.close();
				if(conn!=null) conn.close();
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
	
		//���
		//1.�α���
		/*
		 * 		0 = ID(X)
		 * 		1 = PWD(X)
		 * 		2 = OK(�α���)
		 */
		public int isLogin(String id,String pwd){
			int result=0;
			
			try{
				getConnection();
				/*
					SELECT COUNT(*) FROM member
					WHERE id='jung';				 * 
				 */
				String sql="SELECT COUNT(*) FROM member "
						+"WHERE id=?";
				ps=conn.prepareStatement(sql);
				ps.setString(1, id);
				ResultSet rs=ps.executeQuery();
				rs.next();
				int count=rs.getInt(1);
				rs.close();
				
				if(count==0){	//ID(X)
					result=0;
				}else{			//ID(O)
					/*
					SELECT pwd FROM member
					WHERE id='jung';					 * 
					 */
					sql="SELECT pwd FROM member "
							+"WHERE id=?";
					ps=conn.prepareStatement(sql);
					ps.setString(1, id);
					rs=ps.executeQuery();
					rs.next();
					String db_pwd=rs.getString(1);
					rs.close();
					
					if(db_pwd.equals(pwd)){
						result=2;
					}else{
						result=1;
					}
				}
				
				
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}finally{
				disConnection();
			}
			
			return result;
		}
		
		//2.�̸��� ����
		public String getLogData(String id){
			String result="";
			
			try{
				getConnection();
				
				/*
					SELECT name FROM member
					WHERE id='jung';
				 */
				String sql="SELECT name FROM member "
						+"WHERE id=?";
				ps=conn.prepareStatement(sql);
				ps.setString(1, id);
				ResultSet rs=ps.executeQuery();
				rs.next();
				result=rs.getString(1);
				rs.close();
				
				
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}finally{
				disConnection();
			}
			
			return result;
		}
}





















