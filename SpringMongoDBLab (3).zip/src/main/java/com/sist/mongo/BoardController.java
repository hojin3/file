package com.sist.mongo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sist.dao.BoardDAO;
import com.sist.dao.BoardVO;

@Controller
public class BoardController {
	@Autowired
	private BoardDAO dao;
	@RequestMapping("board/list.do")
	public String board_list(String page,Model model){
		if(page==null)
			page="1";
		int curpage=Integer.parseInt(page);
		
		List<BoardVO> list=dao.boardListData(curpage);
		int totalpage=dao.boardTotalPage();
		
		model.addAttribute("curpage", curpage);
		model.addAttribute("totalpage", totalpage);
		model.addAttribute("list", list);
		
		return "board/list";
	}
	
	@RequestMapping("board/insert.do")
	public String board_insert(){
		return "board/insert";
	}
	
	@RequestMapping("board/insert_ok.do")
	public String board_insert_ok(BoardVO vo){
		dao.boardInsert(vo);
		return "redirect:/board/list.do";
	}
	
	@RequestMapping("board/content.do")
	public String board_content(int no,int page,Model model){
		BoardVO vo=dao.boardContentData(no);
		
		//...
		
		model.addAttribute("vo", vo);
		model.addAttribute("page", page);	
		
		return "board/content";
	}
	
	@RequestMapping("board/delete_ok.do")
	@ResponseBody
	public String board_delete_ok(int page,int no,String pwd){
		String url="";
		boolean bCheck=dao.boardDelete(no, pwd);
		if(bCheck==true){
			url="<script>"
					+"location.href=\"list.do?page="+page+"\";"
					+"</script>";
		}else{
			url="<script>alert(\"��й�ȣ�� Ʋ���ϴ�.\");history.back();</script>";
		}
		
		
		
		return url;
	}
}










