package com.client;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

public class WaitRoom extends JPanel{
	JTable table;				//��� ���
	DefaultTableModel model;	//������ ����
	JButton b1,b2,b3;
	JTextPane tp;
	JComboBox box;
	JTextField tf;
	JButton[] poster=new JButton[7];
	JLabel poLa;
	JLabel[] la=new JLabel[7];
	JTextField[] mtf=new JTextField[7];
	JTabbedPane pane;
	JTable table1,table2,table3;
	DefaultTableModel modle1,model2,model3;
	TableColumn column;
	
	public WaitRoom(){
		String[] col={"ID","�̸�","����"};
		String[][] row=new String[0][3];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		
		table=new JTable(model);
		JScrollPane js=new JScrollPane(table);
		
		b1=new JButton("����������");
		b2=new JButton("��������");
		b3=new JButton("������");
		JPanel p=new JPanel();
		p.add(b1);
		p.add(b2);
		p.add(b3);
		
		tp=new JTextPane();
		tp.setEditable(false); 		//���� ����
		JScrollPane js1=new JScrollPane(tp);
		
		tf=new JTextField();
		box=new JComboBox();
		box.addItem("black");
		box.addItem("red");
		box.addItem("blue");
		box.addItem("green");
		box.addItem("yellow");
				
		setLayout(null);
		js.setBounds(10, 15, 300, 350);
		p.setBounds(10, 270, 300, 25);
		js1.setBounds(10, 310, 300, 300);
		tf.setBounds(10, 615, 200, 30);
		box.setBounds(215, 615, 95, 30);
		
		add(js);
		add(p);
		add(js1);
		add(tf);
		add(box);
		
		
	}
}

















