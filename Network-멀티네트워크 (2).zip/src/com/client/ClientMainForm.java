package com.client;

import java.awt.*;
import javax.swing.*;
import com.sist.common.*;
import java.awt.event.*;
import java.net.*;
import java.io.*;
import java.util.*;

/*
 * �̺�Ʈ (Mouse,Key,Button) ==> server�� ���� run()
 * case Function.~��ûó��
 * server => client ����  (messageTO,messageALL())
 * client => case (run())
 */

public class ClientMainForm extends JFrame
							implements Runnable,ActionListener,MouseListener{
	Login login=new Login();
	WaitRoom wr=new WaitRoom();
	CardLayout card=new CardLayout();
	//
	
	//network
	Socket s;
	BufferedReader in;
	OutputStream out;
	int selNum=-1;
	String myId;
	//
	
	public ClientMainForm() {
		setLayout(card);
		
		add("LOG",login);
		add("WR", wr);
		
		setSize(900, 700);
		setVisible(true);
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		setResizable(false);  	//������ ����
		login.b1.addActionListener(this);
		login.b2.addActionListener(this);
		
		//
		
		
	}
	
	public static void main(String[] args){
		try{
			UIManager.setLookAndFeel("com.jtattoo.plaf.mcwin.McWinLookAndFeel");
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		new ClientMainForm();
	}
	
	
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==login.b1){
			String id=login.tf1.getText();
			if(id.length()<1){
				JOptionPane.showMessageDialog(this, "ID�� �Է��ϼ���.");
				login.tf1.requestFocus();
				return;
			}
			String name=login.tf2.getText();
			if(name.length()<1){
				JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���.");
				login.tf2.requestFocus();
				return;
			}		
			String gender="";
			if(login.rb1.isSelected())
				gender="����";
			else
				gender="����";
			connection(id, name, gender);
			myId=id;
		}
		
	}
	
	public void connection(String id,String name,String gender){
		try{
			s=new Socket("localhost", 3354);	//��������
			
			in=new BufferedReader(new InputStreamReader(s.getInputStream()));
			out=s.getOutputStream();
			out.write((Function.LOGIN+"|"+id
					+"|"+name+"|"
					+gender+"\n").getBytes());
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		new Thread(this).start();
	}
	
	/*
	 *   client : ��û ==> ���� : ��ûó��  ==> ����� ���� (����) => ���(client)
	 *   ============HTML==================JSP=======> HTML
	 *   HTML�� �ڵ� ��ȯ (���)
	 *   client : ��û =>����:��ûó�� ==> ����� ==> ���
	 *   �������α׷� SQL ==> SQL ����  ==> ����� ==> Ŭ���̾�Ʈ ����
	 *   
	 */

	//����
	@Override
	public void run() {
		try{
			while(true){
				//���б�
				String msg=in.readLine();
				StringTokenizer st=new StringTokenizer(msg, "|");
				int index=Integer.parseInt(st.nextToken());
				//100|id|name|gender
				switch(index){
				case Function.LOGIN:{
					String[] data={
						st.nextToken(),
						st.nextToken(),
						st.nextToken()
					};
					wr.model.addRow(data);
				}
				break;
				case Function.MYLOG:{
					String name=st.nextToken();
					String id=st.nextToken();
					setTitle(name);
					//
					card.show(getContentPane(), "WR");
				}
				break;
				}
			}
			
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
		
	}

}





















