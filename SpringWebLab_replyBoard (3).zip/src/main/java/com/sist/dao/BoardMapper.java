package com.sist.dao;

import java.util.*;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

public interface BoardMapper {
	@Select("SELECT no,subject,name,regdate,hit,group_tab,num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab,rownum as num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab "
			+"FROM replyBoard ORDER BY group_id DESC,group_step ASC))"
			+"WHERE num BETWEEN #{start} AND #{end}")
	public List<BoardVO> boardListData(Map map);
			//resultType				parameterType
	
	@Select("SELECT CEIL(COUNT(*)/10) FROM replyBoard")
	public int boardTotalPage();
	
	@Update("UPDATE replyBoard SET "
			+"hit=hit+1 "
			+"WHERE no=#{no}")
	public void boardHitIncrement(int no);
	
	@Select("SELECT no,name,subject,content,regdate,hit "
			+"FROM replyBoard "
			+"WHERE no=#{no}")
	public BoardVO boardContentData(int no);
	
	//�Է��ϱ����� Ư��Ű���� ������ ���� �� ���� �̿��ؼ� ó���Ҷ� ���.
	@SelectKey(keyProperty="no",resultType=int.class,before=true,
			statement="SELECT NVL(MAX(no)+1,1) as no FROM replyBoard")
	@Insert("INSERT INTO replyBoard VALUES("
			+"#{no},#{name},#{email},#{subject},#{content},"
			+"#{pwd},SYSDATE,0,"
			+"(SELECT NVL(MAX(group_id)+1,1) FROM replyBoard),"
			+"0,0,0,0)")
	public void boardInsert(BoardVO vo);
}












