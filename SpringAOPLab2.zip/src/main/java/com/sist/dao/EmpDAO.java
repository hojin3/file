package com.sist.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class EmpDAO {
	private DBConnection dbCon;
	private PreparedStatement ps;

	public DBConnection getDbCon() {
		return dbCon;
	}

	public void setDbCon(DBConnection dbCon) {
		this.dbCon = dbCon;
	}
	
	//��� ����
	public List<EmpVO> empAllData(){
		List<EmpVO> list=new ArrayList<EmpVO>();
		
		try{
			//dbCon.getConnection();
			String sql="SELECT empno,ename,job,hiredate "
					+"FROM emp";
			ps=dbCon.getDbCon().prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				EmpVO vo=new EmpVO();
				vo.setEmpno(rs.getInt(1));
				vo.setEname(rs.getString(2));
				vo.setJob(rs.getString(3));
				vo.setHiredate(rs.getDate(4));
				list.add(vo);
			}
			ps.close();
			rs.close();
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}/*finally{
			dbCon.disConnection();
		}*/		
		return list;
	}
	
	
}





























