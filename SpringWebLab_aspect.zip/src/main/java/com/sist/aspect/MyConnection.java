package com.sist.aspect;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sist.dao.MyDAO;

/*
 * 	JoinPoint (����)
 * 	PointCut 
 * 
 * 	Advice + PointCut => Aspect
 */

@Component
@Aspect
public class MyConnection {
	@Autowired
	private MyDAO dao;
	
	@Before("execution(* com.sist.dao.MyDAO.tx*(..))")
	public void getConnection(){
		dao.getConnection();
	}
	@After("execution(* com.sist.dao.MyDAO.tx*(..))")
	public void disConnection(){
		dao.disConnection();
	}
	//@Around("")
	//@AfterReturning("")
	//@AfterThrowing("")	
}
















