package com.sist.dao;

import org.springframework.stereotype.Repository;

/*
 * 		public void boardInsert(){
 * 			try{
 * ===========================================@Arround
 * 				getConnection();
 * 				conn.setAutoCommit(false);
 * ===========================================
 * 				insert(�԰�);
 * 				update(���);
 * 				delete();
 * ===========================================
 * 				conn.commit();
 * ===========================================
 * 			catch(Exception ex){
 * ===========================================
 * 				conn.rollback();	@After-Throwing
 * ===========================================
 * 			}
 * 			finally{
 * ==========================================
 * 				conn.setAutoCommit(true);
 * 				disConnection();	@After
 * ==========================================
 * 			}
 * 
 * 			@After-Returning
 * 		}
 * 
 * 
 */

@Repository
public class MyDAO {
	public void getConnection(){
		System.out.println("����Ŭ ����Ϸ�");
	}
	public void disConnection(){
		System.out.println("����Ŭ ��������");
	}
	
	public void txselect(){
		//getConnection();		//@Before
		System.out.println("select ����");	
		//disConnection();		//@After
	}
	
	public void txinsert(){
		//getConnection();		//@Before
		System.out.println("insert ����");	
		//disConnection();		//@After		
	}
	
	public void txupdate(){
		//getConnection();		//@Before
		System.out.println("update ����");	
		//disConnection();		//@After		
	}	
	
	public void txdelete(){
		//getConnection();		//@Before
		System.out.println("delete ����");	
		//disConnection();		//@After		
	}		
}










