package com.sist.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.sist.dao.MyDAO;

/*
 * 	XML,Annotation
 * 	====================
 * 		1)DI ==> ����,�޸��Ҵ�
 * 		2)web (MVC) => DI,DAO
 * 		3)AOP => TX(Transaction),SE(Security)
 */

@Component
public class MainClass {
	@Autowired
	private MyDAO dao;
	
	public static void main(String[] args){
		ApplicationContext app=
				new ClassPathXmlApplicationContext("app.xml");
		
		MainClass mc=(MainClass) app.getBean("mainClass");
		mc.dao.txinsert();
		mc.dao.txselect();
		mc.dao.txupdate();
		mc.dao.txdelete();
		
	}
}
































