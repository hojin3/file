package com.sist.dao;
/*
 * 
 ZIPCODE
 SIDO
 GUGUN
 DONG
 BUNJI
 */
public class PostVO {
	private String zipcode;		//������ȣ
	private String sido;		//��,��
	private String gugun;		//��,��
	private String dong;		//��,��,��
	private String bungi;		//����
	private String addr;
	
	
	
	public String getAddr() {
		return sido+" "+gugun+" "+dong+" "+bungi;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getZipcode() {
		return zipcode;
	}
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	public String getSido() {
		return sido;
	}
	public void setSido(String sido) {
		this.sido = sido;
	}
	public String getGugun() {
		return gugun;
	}
	public void setGugun(String gugun) {
		this.gugun = gugun;
	}
	public String getDong() {
		return dong;
	}
	public void setDong(String dong) {
		this.dong = dong;
	}
	public String getBungi() {
		return bungi;
	}
	public void setBungi(String bungi) {
		this.bungi = bungi;
	}
	
}











