package com.sist.dao;

import java.sql.*;		//Connection,PrepareStatement,ResultSet
import java.util.*;		//ArrayList
public class PostDAO {
	//���ᰴü ����
	private Connection conn;
	//���۰�ü ����
	private PreparedStatement ps;
	//����Ŭ �ּ� ����
	private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
	//�̱��� ����, ���丮 ����, Adapter,Observer
	private static PostDAO dao;
	
	//����̹� ���
	public PostDAO(){
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	/*
	 * �޼��� �뵵 :
	 * 	1)�Ѱ� ����� ����
	 *  2)�ݺ� ����.
	 */
	//���� ��ü ����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL,"scott","tiger");
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	//���� ����
	public void disConnection(){
		try{
			if(ps!=null)ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println("disConnection()"+ex.getMessage());
		}
	}
	//�̱� ��
	 public static PostDAO newInstance(){
		 if(dao==null)
			 dao=new PostDAO();
		 return dao;
	 }
	 
	 //���
	 //1.������ȣ �˻�
	 public ArrayList<PostVO> postFindData(String dong){
		 ArrayList<PostVO> list=new ArrayList<>();
		 
		 try{
			 getConnection();
			 String sql="SELECT zipcode,sido,gugun,dong,NVL(bunji,' ') "
					 	+"FROM post "
					 	+"WHERE dong LIKE '%'||?||'%'";
			 ps=conn.prepareStatement(sql);
			 ps.setString(1, dong);
			 ResultSet rs=ps.executeQuery();
			 
			 while(rs.next()){				 
					 PostVO vo=new PostVO();
					 vo.setZipcode(rs.getString(1));
					 vo.setSido(rs.getString(2));
					 vo.setGugun(rs.getString(3));
					 vo.setDong(rs.getString(4));
					 vo.setBungi(rs.getString(5));
					 list.add(vo);
			 }
			 rs.close();
			 
		 }catch(Exception ex){
			 System.out.println("postFindData()"+ex.getMessage());
		 }finally{
			 disConnection();
		 }
		 
		 return list;
	 }
	 //2.�������� 
	 public int postTotal(String dong){
		 int total=0;
		 
		 try{
			 getConnection();
			 String sql="SELECT CEIL(COUNT(*)/10) FROM post "
					 +"WHERE dong LIKE '%'||?||'%'";
			 ps=conn.prepareStatement(sql);
			 ps.setString(1, dong);
			 ResultSet rs=ps.executeQuery();
			 rs.next();
			 total=rs.getInt(1);
			 
			 rs.close();
			 
			 
		 }catch(Exception ex){
			 System.out.println("postTotal()"+ex.getMessage());
		 }finally{
			 disConnection();
		 }
		 
		 return total;
	 }
	 
	 public int postCount(String dong){
		 int count=0;
		 
		 try{
			 getConnection();
			 String sql="SELECT COUNT(*) "
					 +"FROM post "
					 +"WHERE dong LIKE '%'||?||'%'";
			 ps=conn.prepareStatement(sql);
			 ps.setString(1, dong);
			 ResultSet rs=ps.executeQuery();
			 rs.next();
			 count=rs.getInt(1);
			 rs.close();
			 
		 }catch(Exception ex){
			 System.out.println(ex.getMessage());
		 }finally{
			 disConnection();
		 }
		 
		 return count;
	 }
}













