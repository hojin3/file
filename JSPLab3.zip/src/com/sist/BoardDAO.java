package com.sist;

import java.util.*;
import java.sql.*;

public class BoardDAO {
	private Connection conn;
	private PreparedStatement ps;
	private static BoardDAO dao;
	private final String URL="jdbc:oracle:thin:@211.238.142.212:1521:ORCL";
	
	//����̹�
	public BoardDAO(){
		try{
			Class.forName("oracle.jdbc.OracleDriver");
			//Ŭ���������� �о ���� => ���÷���
		}catch(Exception ex){
			System.out.println("BoardDAO()"+ex.getMessage());
			//ex.printStackTrace();
		}
	}
	
	//����
	public void getConnection(){
		try{
			conn=DriverManager.getConnection(URL, "scott", "tiger");
		}catch(Exception ex){
			System.out.println("getConnection()"+ex.getMessage());
		}
	}
	
	//����
	public void disConnection(){
		try{
			if(ps!=null) ps.close();
			if(conn!=null) conn.close();
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
	
	//��Ŭ��
	public static BoardDAO newInstance(){
		if(dao==null)
			dao=new BoardDAO();
		return dao;	
	}
	
	//���
	//1.��� 
	public ArrayList<BoardVO> boardListData(int page){
		ArrayList<BoardVO> list=new ArrayList<>();
		
		try{
			getConnection();
			int rowSize=10;
			int start=(rowSize*page)-(rowSize-1);
			int end=rowSize*page;
			/*
			 *  1-10 11-20 			1-5 6-10
			 */
			String sql="SELECT no,subject,name,regdate,hit,num "
					+"FROM (SELECT no,subject,name,regdate,hit,rownum as num "
					+"FROM (SELECT no,subject,name,regdate,hit "
					+"FROM board ORDER BY no DESC)) "
					+"WHERE num BETWEEN "+start+" AND "+end;
			
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				BoardVO vo=new BoardVO();
				vo.setNo(rs.getInt(1));
				vo.setSubject(rs.getString(2));
				vo.setName(rs.getString(3));
				vo.setRegdate(rs.getDate(4));
				vo.setHit(rs.getInt(5));
				list.add(vo);
			}
			rs.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return list;
	}
	
	public int boardTotalPage(){
		int  total=0;
		
		try{
			getConnection();
			String sql="SELECT CEIL(COUNT(*)/10) FROM board";
			ps=conn.prepareStatement(sql);
			ResultSet rs=ps.executeQuery();
			rs.next();
			total=rs.getInt(1);
			rs.close();
			
		}catch(Exception ex){
			System.out.println("boardTotalPage()"+ex.getMessage());
			//ex.printStackTrace();
		}finally{
			disConnection();
		}
		
		return total;
	}
	
	//2. ���뺸��
	public BoardVO boardContentData(int no){
		BoardVO vo=new BoardVO();
		
		try{
			getConnection();
			String sql="UPDATE board SET "
					+"hit=hit+1 "
					+"WHERE no=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, no);
			ps.executeUpdate();		//COMMIT;
			ps.close();
			
			sql="SELECT * FROM board "
					+"WHERE no=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, no);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			vo.setNo(rs.getInt(1));
			vo.setName(rs.getString(2));
			vo.setEmail(rs.getString(3));
			vo.setSubject(rs.getString(4));
			vo.setContent(rs.getString(5));
			vo.setPwd(rs.getString(6));
			vo.setRegdate(rs.getDate(7));
			vo.setHit(rs.getInt(8));
			rs.close();
			
		}catch(Exception ex){
			System.out.println("boardContentData"+ex.getMessage());
			//ex.printStackTrace();
		}finally{
			disConnection();
		}
		
		return vo;
	}
	
	//3. �����ϱ�
	public boolean boardDelete(int no,String pwd){
		boolean bCheck=false;
		
		try{
			getConnection();
			String sql="SELECT pwd FROM board "
					+"WHERE no=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, no);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			String db_pwd=rs.getString(1);
			rs.close();
			ps.close();
			
			if(db_pwd.equals(pwd)){
				bCheck=true;
				sql="DELETE FROM board "
						+"WHERE no=?";
				ps=conn.prepareStatement(sql);
				ps.setInt(1, no);
				ps.executeUpdate();
			}else{
				bCheck=false;
			}		
			
		}catch(Exception ex){
			System.out.println("boardDelete()"+ex.getMessage());
			//ex.printStackTrace();
		}finally{
			disConnection();
		}
		
		return bCheck;
	}
	
	//4-1. �����ϱ�-�Խñ� ������ �ҷ�����
	public BoardVO boardUpdateData(int no){
		BoardVO vo=new BoardVO();
		
		try{
			getConnection();
			String sql="SELECT * FROM board "
					+"WHERE no=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, no);
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			vo.setNo(rs.getInt(1));
			vo.setName(rs.getString(2));
			vo.setEmail(rs.getString(3));
			vo.setSubject(rs.getString(4));
			vo.setContent(rs.getString(5));
			vo.setPwd(rs.getString(6));
			vo.setRegdate(rs.getDate(7));
			vo.setHit(rs.getInt(8));
			rs.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}finally{
			disConnection();
		}
		
		return vo;
	}
	
	
	
	//4-2. �����ϱ�
	public boolean boardUpdate(BoardVO vo){
		boolean bCheck=false;
		
		try{
			getConnection();
			String sql="SELECT pwd FROM board "
					+"WHERE no=?";
			ps=conn.prepareStatement(sql);
			ps.setInt(1, vo.getNo());
			
			ResultSet rs=ps.executeQuery();
			rs.next();
			String db_pwd=rs.getString(1);
			rs.close();
			ps.close();
			
			if(db_pwd.equals(vo.getPwd())){
				bCheck=true;
				sql="UPDATE board SET "
					+"name=?,email=?,"
					+"subject=?,content=?"
					+"WHERE no=?";
				ps=conn.prepareStatement(sql);
				ps.setString(1, vo.getName());
				ps.setString(2, vo.getEmail());
				ps.setString(3, vo.getSubject());
				ps.setString(4, vo.getContent());
				ps.setInt(5, vo.getNo());
				ps.executeUpdate();
			}else{
				bCheck=false;
			}
			
		}catch(Exception ex){
			System.out.println("boardUpdate()"+ex.getMessage());
		}finally{
			disConnection();
		}
		return bCheck;
	}
}

















