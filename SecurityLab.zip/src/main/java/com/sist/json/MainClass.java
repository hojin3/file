package com.sist.json;

import org.json.simple.*;
import java.io.*;
import java.net.*;

public class MainClass {
	public static void main(String[] args){
		try{
			JSONObject obj=new JSONObject();
			String name="������";
			URLEncoder.encode(name, "EUC-KR");
			obj.put("name", name);
			obj.put("age", 30);
			
			String gender="����";
			URLEncoder.encode(gender, "EUC-KR");
			obj.put("gender", gender);
			
			JSONArray list=new JSONArray();
			list.add("010-1234-5678");
			list.add("02-345-6789");
			list.add("02-1239-2345");
			obj.put("phone", list);
			
			FileOutputStream file=
					new FileOutputStream("./info.json");
			file.write(obj.toJSONString().getBytes("EUC-KR"));
			file.flush();
			file.close();
			
		}catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
}

















