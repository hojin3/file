package com.sist2;

import javax.swing.*;

public class MultiThreadTest extends JFrame{
	
	GameView gv=new GameView();
	
	public MultiThreadTest(){
		add("Center",gv);
		setSize(335,460);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public static void main(String[] args){
		new MultiThreadTest();
	}
}














