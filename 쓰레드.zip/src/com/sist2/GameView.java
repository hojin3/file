package com.sist2;

import java.awt.*;
import javax.swing.*;

public class GameView extends JPanel{
	Image img0,img1,img21,img31;
	int no=0;
	Image[] front=new Image[4];
	Image move;
	int x=145,y=330;
	int mv=0;
	
	public GameView(){
		img0=Toolkit.getDefaultToolkit().getImage("c:\\image\\img0.png");
		img1=Toolkit.getDefaultToolkit().getImage("c:\\image\\img1.png");
		img21=Toolkit.getDefaultToolkit().getImage("c:\\image\\img21.png");
		img31=Toolkit.getDefaultToolkit().getImage("c:\\image\\img31.png");
		
		for(int i=0;i<4;i++){
			front[i]=
				Toolkit.getDefaultToolkit().getImage("c:\\image\\front0"+(i+1)+".png");
		}
		move=front[0];
		
		new BackThread().start();
		new MoveThread().start();
		
	}
	
	@Override
	public void paint(Graphics g) {
		g.drawImage(img0, 0, 0, 320, 90, this);
		g.drawImage(img1, 0, 90, 320, 100, this);
		g.drawImage(img21, 0, 190, 320, 120, this);
		g.drawImage(img31, 0, 310, 320, 120, this);
		g.drawImage(move,x,y,this);
	}
	
	class BackThread extends Thread{
		
		@Override
		public void run() {
			try{
				while(true){
					no++;
					if(no%2==0){
						img21=Toolkit.getDefaultToolkit().getImage("c:\\image\\img21.png");
						img31=Toolkit.getDefaultToolkit().getImage("c:\\image\\img31.png");
					}else{
						img21=Toolkit.getDefaultToolkit().getImage("c:\\image\\img22.png");
						img31=Toolkit.getDefaultToolkit().getImage("c:\\image\\img32.png");
					}
					repaint();
					Thread.sleep(100);
				}
				
				
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}

		}
	}
	
	class MoveThread extends Thread{
		@Override
		public void run() {
			while(true){
				mv++;
				if(mv%2==0){
					x-=5;
				}else{
					x+=5;
				}
				for(int i=0;i<4;i++){
					move=front[i];
					try{
						Thread.sleep(50);
					}catch(Exception ex){
						System.out.println(ex.getMessage());
					}
				}
				repaint();
				try{
					Thread.sleep(100);
				}catch(Exception ex){
					System.out.println(ex.getMessage());
				}
			}
		}
	}
	
}


























