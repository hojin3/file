package com.sist3;

import java.awt.*;
import java.util.Random;

import javax.swing.*;

public class GameView extends JPanel{
	Image back,move;
	int x=670,y=480;
	MoveThread[] mt=new MoveThread[5];
	
	public GameView() {
		back=Toolkit.getDefaultToolkit().getImage("c:\\image\\back1.jpg");
		move=Toolkit.getDefaultToolkit().getImage("c:\\image\\horse.gif");
		
		mt[0]=new MoveThread(650, 160);
		mt[1]=new MoveThread(650, 240);
		mt[2]=new MoveThread(650, 320);
		mt[3]=new MoveThread(650, 400);
		mt[4]=new MoveThread(650, 480);
		mt[0].start();
		mt[1].start();
		mt[2].start();
		mt[3].start();
		mt[4].start();
		
	}
	
	@Override
	public void paint(Graphics g) {
		g.drawImage(back, 0, 0, getWidth(), getHeight(), this);
		for(int i=0;i<5;i++){
			g.drawImage(move, mt[i].x, mt[i].y, this);
		}
	}
	
	class MoveThread extends Thread{
		int x=650,y;
		int count=0;
		
		public MoveThread(int x,int y){
			this.x=x;
			this.y=y;
		}
		
		@Override
		public void run() {
			Random r=new Random();
			
			try{
				while(true){
					x-=5;
					if(x<0){
						x=800;
					}
					Thread.sleep(r.nextInt(200));	//0~199������ ������ ����
				}
				
				
			}catch(Exception ex){
				System.out.println(ex.getMessage());
			}
		}
	}
}





















