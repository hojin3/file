package com.sist3;

import javax.swing.*;

public class GameViewTest extends JFrame {
	GameView gv=new GameView();
	
	public GameViewTest(){
		add("Center",gv);
		setSize(800, 600);
		setVisible(true);
	}
	
	public static void main(String[] args){
		new GameViewTest();
	}
}














