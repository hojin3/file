package com.sist4;

import javax.swing.*;
import java.awt.event.*;

public class GameTest extends JFrame implements ActionListener{
	GameView2 gv=new GameView2();
	JMenuItem start,stop,exit;
	
	public GameTest(){
		JMenuBar bar=new JMenuBar();
		JMenu menu=new JMenu("Game");
		start=new JMenuItem("Start");
		stop=new JMenuItem("Stop");
		exit=new JMenuItem("Exit");
		
		menu.add(start);
		menu.add(stop);
		menu.add(exit);
		
		bar.add(menu);
		setJMenuBar(bar);
		add("Center",gv);
		
		setSize(800, 600);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		start.addActionListener(this);
		stop.addActionListener(this);
		exit.addActionListener(this);
	}
	
	public static void main(String[] args){
		new GameTest();
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==start){
			GameView2.bThread=true;
			gv.startThread();
			gv.t.start();
		}
		if(e.getSource()==stop){
			GameView2.bThread=false;
		}
		if(e.getSource()==exit){
			gv.t.interrupt();
			System.exit(0);
		}
	}

}













