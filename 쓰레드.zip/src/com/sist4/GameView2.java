package com.sist4;

import java.awt.*;
import javax.swing.*;

public class GameView2 extends JPanel{
	Image back,sky;
	int x=10,y=10;
	static boolean bThread=false;
	SkyThread t=new SkyThread();
	Image[] bomb=new Image[4];
	boolean bBomb=false;
	
	public GameView2(){
		back=Toolkit.getDefaultToolkit().getImage("c:\\image\\back.jpg");
		sky=Toolkit.getDefaultToolkit().getImage("c:\\image\\aaa.gif");
		for(int i=0;i<4;i++){
			bomb[i]=Toolkit.getDefaultToolkit().getImage("c:\\image\\bomb"+(i+1)+".png");
		}
	}
	
	public void startThread(){
		t=new SkyThread();		//������ ����
	}
	
	@Override
	public void paint(Graphics g) {
		t.getGraphics(g);
		g.drawImage(back, 0, 0, 800, 600, this);
		g.drawImage(sky, x, y, this);
	}
	
	
	class SkyThread extends Thread{
		Graphics g;
		
		public void getGraphics(Graphics g){
			this.g=g;
		}
		
		@Override
		public void run() {
			while(bThread){
				try{
					x+=5;
					
					if(x>800)
						x=0;
					
					//��ź������ ����
					if(x==200){
						bThread=false;
						interrupt();
						
						bBomb=true;
						if(bBomb==true){
							for(int i=0;i<4;i++){
								try{
									sky=bomb[i];
									g.drawImage(sky, x, y, GameView2.this);
									Thread.sleep(300);
									
								}catch(Exception ex){
									System.out.println(ex.getMessage());
								}
							}
						}
					}
					
					Thread.sleep(100);
					repaint();
					
				}catch(Exception ex){
					System.out.println(ex.getMessage());
				}
			}
			sky=Toolkit.getDefaultToolkit().getImage("c:\\image\\aaa.gif");
			repaint();
		}
	}
}














