package com.sist.main;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumn;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.text.SimpleDateFormat;
import java.util.*;
import com.sist.sawon.*;

public class SawonMainForm extends JFrame implements ActionListener,MouseListener{

	JTable table;
	DefaultTableModel model;
	JLabel titleLa;
	JLabel la,pageLa;
	JButton b1,b2,b3,b4,b5,b6;
	JComboBox box;
	JTextField tf;
	SawonManager sm=new SawonManager();
	SawonUIForm sf=new SawonUIForm();
	int curpage=1;
	int totalpage=0;
	TableColumn column;
	JPanel p1=new JPanel();
	JPanel p2=new JPanel();
	int selRow=-1;
	
	public SawonMainForm() {
		titleLa=new JLabel("��� ���� ���α׷�",JLabel.CENTER);
		titleLa.setFont(new Font("���� ����", Font.BOLD, 30));
		
		setLayout(null);
		titleLa.setBounds(10, 15, 600, 45);
		b1=new JButton("���");
		b1.setBounds(10, 65, 80, 30);
		b6=new JButton("����");
		b6.setBounds(95, 65, 80, 30);
		
		String[] col={"���","�̸�","�μ�","����","�ٹ���"};
		String[][] row=new String[0][5];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};	//�͸�Ŭ����
		
		table=new JTable(model);
		
		table.getTableHeader().setBackground(Color.orange);
		table.setShowGrid(false);
		table.setRowHeight(27);
		table.getTableHeader().setReorderingAllowed(false);
		table.getTableHeader().setResizingAllowed(false);
		JScrollPane js=new JScrollPane(table);
		js.getViewport().setBackground(Color.WHITE);
		js.setBounds(10, 100, 600, 290);
		
		la=new JLabel("Search");
		box=new JComboBox();
		box.addItem("�̸�");
		box.addItem("�μ�");
		box.addItem("�ٹ���");
		box.addItem("����");
		tf=new JTextField(5);
		b2=new JButton("ã��");
		b5=new JButton("���");
		
		p1.add(la);
		p1.add(box);
		p1.add(tf);
		p1.add(b2);
		p1.add(b5);
		p1.setBounds(10, 400, 350, 35);
		
		b3=new JButton("����");
		b4=new JButton("����");
		pageLa=new JLabel("0 page / 0 pages");
		p2.add(b3);
		p2.add(b4);
		p2.add(pageLa);
		p2.setBounds(370, 400, 250, 35);
		
		add(b1);
		add(b6);
		add(p1);
		add(p2);
		add(js);
		add(titleLa);
		
		setBounds(200, 100, 640, 480);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		getData();	//������
		
		for(int i=0;i<col.length;i++){
			column=table.getColumnModel().getColumn(i);
			DefaultTableCellRenderer rand=new DefaultTableCellRenderer();
			rand.setHorizontalAlignment(JLabel.CENTER);
			column.setCellRenderer(rand);
		}
		
		//�����ʵ��
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		b4.addActionListener(this);
		b5.addActionListener(this);
		b6.addActionListener(this);
		sf.b1.addActionListener(this);
		sf.b2.addActionListener(this);
		table.addMouseListener(this);
		
	}
	
	//������ ��������
	public void getData(){
		for(int i=model.getRowCount()-1;i>=0;i--){
			model.removeRow(i);
		}
		
		ArrayList<SawonVO> list=sm.sawonAllData(curpage);
		for(int i=0;i<list.size();i++){
			SawonVO vo=list.get(i);
			String[] data={
				String.valueOf(vo.getSabun()),
				vo.getName(),
				vo.getDept(),
				vo.getLoc(),
				vo.getJob()
			};
			model.addRow(data);
		}
		totalpage=sm.sawonTotalPage();
		pageLa.setText(curpage+" page / "+totalpage+" pages");
		
	}
	
	//Ư�� ������ ã��
	public void getFindData(String fs,String ss){
		for(int i=model.getRowCount()-1;i>=0;i--){
			model.removeRow(i);
		}
		
		ArrayList<SawonVO> list=sm.sawonFind(fs, ss);
		for(int i=0;i<list.size();i++){
			SawonVO vo=list.get(i);
			String[] data={
					String.valueOf(vo.getSabun()),
					vo.getName(),
					vo.getDept(),
					vo.getLoc(),
					vo.getJob()					
			};
			model.addRow(data);
		}
		
		
	}
	
	public static void main(String[] args){
		new SawonMainForm();
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b3){			//����
			
		}else if(e.getSource()==b1){	//���
			sf.tf.setText("");
			sf.box1.setSelectedItem(0);
			sf.box2.setSelectedItem(0);
			sf.box3.setSelectedItem(0);
			sf.tf2.setText("");
			sf.setBounds(380, 220, 240, 275);
			sf.setVisible(true);
			sf.tf.requestFocus();
		}else if(e.getSource()==b2){	//�˻�(ã��)
			p2.setVisible(false);
			String fs=box.getSelectedItem().toString();
			String ss=tf.getText();
			getFindData(fs, ss);
		}else if(e.getSource()==b5){	//���
			p2.setVisible(true);
			getData();
		}else if(e.getSource()==sf.b1){	//SawonUIFormâ���� ��� ���
			String name=sf.tf.getText();
			if(name.length()<1){
				JOptionPane.showMessageDialog(this, "�̸��� �Է��ϼ���");
				sf.tf.requestFocus();
				return;
			}
			String dept=sf.box1.getSelectedItem().toString();
			String loc=sf.box2.getSelectedItem().toString();
			String job=sf.box3.getSelectedItem().toString();
			String pay="";
			int i=0;
			try{
				pay=sf.tf2.getText();
				i=Integer.parseInt(pay);
			}catch(Exception ex){
				JOptionPane.showMessageDialog(this, "���ڸ� �Է��ϼ���");
				sf.tf2.setText("");
				sf.tf2.requestFocus();
				return;
			}
			
			SawonVO vo=new SawonVO();
			vo.setName(name);
			vo.setDept(dept);
			vo.setJob(job);
			vo.setLoc(loc);
			vo.setPay(i);
			vo.setHiredate(new SimpleDateFormat("yyyy-MM-dd").format(new Date()));
			
			sm.sawonInsert(vo);
			getData();
			sf.setVisible(false);
		}else if(e.getSource()==sf.b2){		//SawonUIForm�� ��ҹ�ư
			sf.setVisible(false);
		}
		
	}

}














