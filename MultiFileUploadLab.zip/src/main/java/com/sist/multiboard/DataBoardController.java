package com.sist.multiboard;

import org.springframework.stereotype.Controller;

@Controller
public class DataBoardController {

}
