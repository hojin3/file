package com.sist.dao;

public interface DataBoardMapper {

}
