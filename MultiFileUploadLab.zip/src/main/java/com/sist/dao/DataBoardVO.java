package com.sist.dao;

public class DataBoardVO {

}
