package com.sist.emp;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import com.sist.dao.*;

public class PostClient extends JFrame implements ActionListener,MouseListener{

	JLabel la1,la2,la3;
	JTextField tf1,tf2,tf3,tf4;
	JButton b;
	JTable table;
	DefaultTableModel model;
	JScrollPane js;
	JLabel pla;
	JButton b1,b2;
	
	int curpage=1;
	int totalPage=0;
	
	public PostClient(){
		la1=new JLabel("�Է�");
		la2=new JLabel("������ȣ");
		la3=new JLabel("�ּ�");
		tf1=new JTextField();
		tf2=new JTextField();
		tf3=new JTextField();
		tf4=new JTextField();
		tf2.setEnabled(false);
		tf3.setEnabled(false);
		tf4.setEnabled(false);
		
		b=new JButton("�˻�");
		b1=new JButton("����");
		b2=new JButton("����");
		
		pla=new JLabel("0 page/ 0 pages");
		
		String[] col={"������ȣ","�ּ�"};
		String[][] row=new String[0][2];
		model=new DefaultTableModel(row, col){
			@Override
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		table=new JTable(model);
		js=new JScrollPane(table);
		
		setLayout(null);
		la1.setBounds(10, 15, 60, 30);
		tf1.setBounds(75, 15, 150, 30);
		b.setBounds(230, 15, 100, 30);
		
		la2.setBounds(10, 50, 60, 30);
		tf2.setBounds(75, 50, 70, 30);
		tf3.setBounds(150, 50, 70, 30);
		
		la3.setBounds(10, 85, 60, 30);
		tf4.setBounds(75, 85, 350, 30);
		
		js.setBounds(10, 120, 450, 300);
		js.setVisible(false);
		
		b1.setBounds(100, 425, 80, 30);
		b2.setBounds(190, 425, 80, 30);
		pla.setBounds(290, 425, 170, 30);
		b1.setVisible(false);
		b2.setVisible(false);
		pla.setVisible(false);
		
		add(la1);add(tf1);add(b);
		add(la2);add(tf2);add(tf3);
		add(la3);add(tf4);
		add(js);
		add(b1);add(b2);add(pla);
		
		setSize(490, 510);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		b.addActionListener(this);
		b1.addActionListener(this);
		b2.addActionListener(this);
		table.addMouseListener(this);
	}
	
	public static void main(String[] args){
		new PostClient();
	}
	
	@Override
	public void mouseClicked(MouseEvent e) {
		if(e.getSource()==table){
			if(e.getClickCount()==2){
				int row=table.getSelectedRow();
				String zip=model.getValueAt(row, 0).toString();
				String addr=model.getValueAt(row, 1).toString();
				
				js.setVisible(false);
				b1.setVisible(false);
				b2.setVisible(false);
				pla.setVisible(false);
				
				tf2.setText(zip.substring(0, 3));
				tf3.setText(zip.substring(4, 7));
				tf4.setText(addr);
			}
		}
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b){
			String dong=tf1.getText();
			if(dong.length()<1){
				JOptionPane.showMessageDialog(this, "��/��/���� �Է��ϼ���.");
				tf1.requestFocus();
				return;
			}
			getData(dong);
		}else if(e.getSource()==b1){
			if(curpage>1){
				curpage--;
				getData(tf1.getText());
			}
		}else if(e.getSource()==b2){
			if(curpage<totalPage){
				curpage++;
				getData(tf1.getText());
			}
		}
		
	}
	
	public void getData(String dong){
		PostDAO dao=PostDAO.newInstance();
		ArrayList<PostVO> list=dao.postFindData(curpage, dong);
		if(list.size()<1 || list==null){
			JOptionPane.showMessageDialog(this, "�˻������ �����ϴ�.");
		}else{
			for(int i=model.getRowCount()-1;i>=0;i--){
				model.removeRow(i);
			}
			
			for(PostVO vo:list){
				String[] data={
						vo.getZipcode(),
						vo.getSido()+" "
						+vo.getGugun()+" "
						+vo.getDong()+" "
						+vo.getBunji()
				};
				model.addRow(data);
			}
			totalPage=dao.postTotal(dong);
			pla.setText(curpage+" page / "+totalPage+" pages");
			js.setVisible(true);
			b1.setVisible(true);
			b2.setVisible(true);
			pla.setVisible(true);
		}
	}
	
}


















