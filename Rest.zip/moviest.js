/**
 * http://usejsdoc.org/
 * 
 * movieData.json
 */
var http=require('http');
var fs=require('fs');

var data=fs.readFileSync('./movieData.json');
var movieList=JSON.parse(data);

var server=http.createServer(function(req,res){
	var method=req.method.toLowerCase();
	switch(method){
	case 'get':
		//영화목록 보기  		: /movies
		//영화상세 정보 보기	: /movies/1, /movies/2
		handleGetRequest(req, res);
		return;
	case 'post':
		//영화정보 추가              : /movies
		handlePostRequest(req,res);
		return;
	case 'put':
		//영화정보 수정
		handlePutRequest(req,res);
		return;
	case 'delete':
		//영화정보 삭제
		handleDeleteRequest(req,res);
		return;
	}
});
server.listen(3000,function(){
	console.log("Server Starting: port=300");
});

function handleGetRequest(req,res){
	var url=req.url;
	if(url=='/movies'){
		//영화 목록 만들기
		var list=[];
		for(var i=0;i<movieList.length;i++){
			var movie=movieList[i];
			list.push({id:movie.id, title:movie.title});
		}
		
		//항목 갯수와 영화 목록 정보
		var result={
				count: list.length,
				data: list
		}
		
		res.writeHead(200, 
			{'Content-Type':'application/json;charset=utf-8'});
		res.end(JSON.stringify(result));
		
	}else{
		
	}
}




function handlePostRequest(req,res){
	
}

function handlePutRequest(req,res){
	
}

function handleDeleteRequest(req,res){
	
}

















