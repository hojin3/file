package com.sist.dao;

import java.util.*;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.SelectKey;
import org.apache.ibatis.annotations.Update;

public interface BoardMapper {
	@Select("SELECT no,subject,name,regdate,hit,group_tab,num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab,rownum as num "
			+"FROM (SELECT no,subject,name,regdate,hit,group_tab "
			+"FROM replyBoard ORDER BY group_id DESC,group_step ASC))"
			+"WHERE num BETWEEN #{start} AND #{end}")
	public List<BoardVO> boardListData(Map map);
			//resultType				parameterType
	
	@Select("SELECT CEIL(COUNT(*)/10) FROM replyBoard")
	public int boardTotalPage();
	
	@Update("UPDATE replyBoard SET "
			+"hit=hit+1 "
			+"WHERE no=#{no}")
	public void boardHitIncrement(int no);
	
	@Select("SELECT no,name,subject,content,regdate,hit "
			+"FROM replyBoard "
			+"WHERE no=#{no}")
	public BoardVO boardContentData(int no);
	
	//�Է��ϱ����� Ư��Ű���� ������ ���� �� ���� �̿��ؼ� ó���Ҷ� ���.
	@SelectKey(keyProperty="no",resultType=int.class,before=true,
			statement="SELECT NVL(MAX(no)+1,1) as no FROM replyBoard")
	@Insert("INSERT INTO replyBoard VALUES("
			+"#{no},#{name},#{email},#{subject},#{content},"
			+"#{pwd},SYSDATE,0,"
			+"(SELECT NVL(MAX(group_id)+1,1) FROM replyBoard),"
			+"0,0,0,0)")
	public void boardInsert(BoardVO vo);
	
	
	
	@Select("SELECT pwd FROM replyBoard "
			+"WHERE no=#{no}")
	public String boardGetPwd(int no);
	@Update("UPDATE replyBoard SET "
			+"name=#{name},email=#{email},"
			+"subject=#{subject},content=#{content} "
			+"WHERE no=#{no}")
	public void boardUpdate(BoardVO vo);
	

	//�亯�ϱ�
	@Select("SELECT group_id,group_step,group_tab "
			+"FROM replyBoard "
			+"WHERE no=#{no}")
	public BoardVO boardParentData(int no);
						//group_id: ������ ���� �����ִ� �÷�
						//group_tab: �� ��° �ܰ��� �亯���� ��Ÿ���� �÷�
						//group_step: ���� ���� ������ �������ִ� �÷�.
	/*					group_id	group_tab	group_step
	 *   ��(50)				50			0			0
	 *    |
	 *    |-�亯1				50			1			1
	 *    	 |
	 *    	 |-�亯1�� �亯		50			2			2
	 *    		 |
	 *    		 |-3�ܰ��� �亯   50			3			3
	 *    		 	  |
	 *    			  |-4~  50			4			4
	 * 
	 * 	   -�亯2				50			1	 		4=>5
	 */
	@Update("UPDATE replyBoard SET "
			+"group_step=group_step+1 "
			+"WHERE group_id=#{group_id} "
			+"AND group_step>#{group_step}")
	public void boardStepIncrement(BoardVO vo);
	
	@SelectKey(keyProperty="no",resultType=int.class,before=true,
		statement="SELECT NVL(MAX(no)+1,1) as no FROM replyBoard")
	@Insert("INSERT INTO replyBoard VALUES("
			+"#{no},#{name},#{email},#{subject},#{content},"
			+"#{pwd},SYSDATE,0,"
			+"#{group_id},"
			+"#{group_step},#{group_tab},#{root},0)")
	public void boardReplyInsert(BoardVO vo);
	
	@Update("UPDATE replyBoard SET "
			+"depth=depth+1 "
			+"WHERE no=#{no}")
	public void boardDepthIncreament(int no);
}












