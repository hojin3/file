package com.sist.dao;

import java.util.*;

import org.apache.commons.collections.map.HashedMap;
import org.mybatis.spring.support.SqlSessionDaoSupport;

public class BoardDAO extends SqlSessionDaoSupport{
	
	
	public List<BoardVO> boardListData(int page){
		List<BoardVO> list=new ArrayList<BoardVO>();
		
		int rowSize=10;
		int start=(rowSize*page)-(rowSize-1);
		int end=rowSize*page;
		Map map=new HashMap();
		map.put("pStart", start);
		map.put("pEnd", end);
		getSqlSession().update("boardListData", map);
		list=(List<BoardVO>) map.get("pResult");
		
		return list;
	}
	
	public int boardTotalPage(){
		int total=0;
		Map map=new HashMap();
		getSqlSession().update("boardTotalPage", map);
		total=(Integer) map.get("pNumber");
		
		return total;
	}
	
	public BoardVO boardContentData(int no){
		Map map=new HashMap();
		map.put("pNo", no);
		getSqlSession().update("boardContentData", map);
		List<BoardVO> list=(List<BoardVO>) map.get("pResult");
		return list.get(0);
	}
	
	public void boardInsert(BoardVO vo){
		Map map=new HashMap();
		map.put("pName", vo.getName());
		map.put("pSub", vo.getSubject());
		map.put("pCont", vo.getContent());
		map.put("pPwd", vo.getPwd());
		getSqlSession().update("boardInsert",map);	
	}
	
	public boolean boardDelete(int no,String pwd){
		boolean bCheck=false;
		Map map=new HashMap();
		map.put("pNo", no);
		map.put("pPwd",pwd);
		getSqlSession().update("boardDelete",map);
		String res=(String) map.get("pResult");
		bCheck=Boolean.parseBoolean(res);
		
		return bCheck;
	}
	
}

















