package com.sist.trigger;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class TrrigerDAO {
	@Autowired
	private TriggerMapper mapper;
	
	public List<GoodsVO> goodsAllData(){
		return mapper.goodsAllData();
	}
	
	public void  inputInsert(InputVO vo){
		mapper.inputInsert(vo);
	}
	
	public void salesInsert(SalesVO vo){
		mapper.salesInsert(vo);
	}
}
















