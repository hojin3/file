package com.sist.dao;

import org.apache.ibatis.annotations.Select;

public interface MemberMapper {

	@Select("Select COUNT(*) FROM springMember "
			+"WHERE id=#{id}")
	public int memberIdCheck(String id);
}
