package com.sist.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("md")
public class MemberDAO implements MemberService {
	@Autowired
	private MemberMapper mapper;
	@Override
	public int memberIdCheck(String id) {
		
		return mapper.memberIdCheck(id);
	}

	@Override
	public String memberGetPassword(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<MemberVO> memberLoginCount() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void memberUpdate(String id) {
		// TODO Auto-generated method stub

	}

}
