package com.sist.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository("md")
public class MemberDAO implements MemberService {
	@Autowired
	private MemberMapper mapper;
	@Override
	public int memberIdCheck(String id) {
		
		return mapper.memberIdCheck(id);
	}

	@Override
	public String memberGetPassword(String id) {
		
		return mapper.memberGetPassword(id);
	}

	@Override
	public List<MemberVO> memberLoginCount() {
		
		return mapper.memberLoginCount();
	}

	@Override
	public void memberUpdate(String id) {
		mapper.memberUpdate(id);

	}

}
