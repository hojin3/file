package com.sist.dao;
/*
  id        VARCHAR2(20)      PRIMARY KEY,
  pwd       VARCHAR2(10)      NOT NULL,
  name      VARCHAR2(34)      NOT NULL,
  count     NUMBER * 
 */
public class MemberVO {
	private String id;
	private String pwd;
	private String name;
	private int count;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	
}
















