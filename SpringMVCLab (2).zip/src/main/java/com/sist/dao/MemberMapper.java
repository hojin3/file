package com.sist.dao;

import java.util.List;

import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

public interface MemberMapper {

	@Select("Select COUNT(*) FROM springMember "
			+"WHERE id=#{id}")
	public int memberIdCheck(String id);
	
	@Select("SELECT pwd FROM springMember "
			+"WHERE id=#{id}")
	public String memberGetPassword(String id);
	
	@Select("SELECT id,name,count FROM springMember")
	List<MemberVO> memberLoginCount();
	
	@Update("UPDATE springMember SET "
			+"count=count+1 "
			+"WHERE id=#{id}")
	public void memberUpdate(String id);
}

















