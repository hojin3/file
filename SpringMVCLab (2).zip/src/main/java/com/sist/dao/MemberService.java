package com.sist.dao;

import java.util.List;

public interface MemberService {
	public int memberIdCheck(String id);
	public String memberGetPassword(String id);
	public List<MemberVO> memberLoginCount();
	public void memberUpdate(String id);
	
}
















