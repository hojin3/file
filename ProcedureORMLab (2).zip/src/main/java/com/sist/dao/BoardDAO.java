package com.sist.dao;

import java.util.*;
import org.mybatis.spring.support.SqlSessionDaoSupport;

public class BoardDAO extends SqlSessionDaoSupport{
	
	
	public List<BoardVO> boardListData(int page){
		List<BoardVO> list=new ArrayList<BoardVO>();
		
		int rowSize=10;
		int start=(rowSize*page)-(rowSize-1);
		int end=rowSize*page;
		Map map=new HashMap();
		map.put("pStart", start);
		map.put("pEnd", end);
		getSqlSession().update("boardListData", map);
		list=(List<BoardVO>) map.get("pResult");
		
		return list;
	}
	
	public int boardTotalPage(){
		int total=0;
		Map map=new HashMap();
		getSqlSession().update("boardTotalPage", map);
		total=(Integer) map.get("pNumber");
		
		return total;
	}
	
}

















