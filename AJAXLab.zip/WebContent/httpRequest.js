/**
 * *AJAX 주요 구성 요소.
 * 
 * 	XMLHttpRequest : 웹서버와 통신을 담당함.
 * 					 사용자의 요청을 웹서버에 전송하고
 * 					 웹서버부터 받은 결과를 브라우저에 전달.
 *  DOM : 문서의 구조를 나타냄.
 *  	  폼등의 정보나 화면 구성을 조작할때 사용.
 *  CSS
 *  자바스크립트 : 사용자가 마우스를 드래그,버튼 클릭시 XMLHttpRequest 객체를 사용하여
 *  		  웹서버에 요청을 전송.
 *  		  XMLHttpRequest 객체로부터 응답이 오면 DOM CSS를 사용하여 화면 조작.
 * 
 * 
 * *AJAX와 기존 방식의 차이점
 * 		: 웹브라우저가 아닌 XMLHttpRequest 객체가 웹서버와 통신한다.
 * 		  웹서버의 응답 결과가 HTML이 아닌 XML 또는 단순 텍스트,JSON이다.
 * 		  페이지 이동없이 결과가 화면에 반영됨.
 * 
 * *XMLHttpRequest 프로그래밍 순선
 * 	  1)XMLHttpRequest 객체 구하기.
 * 	  2)웹서버에 요청 전송하기
 *    3)웹서버에 응답이 도착하면 화면에 반영하기.
 */
function getXMLRequest(){
	/*
	 * 	IE의 경우 XMLHttpRequest 객체구하기
	 */
	if(window.ActiveXObject){
		try{
			return new ActiveXObject("Msxml2.XMLHTTP");
		}catch(e){
			try{
				return new ActiveXObject("Microsoft.XMLHTTP");
			}catch(e1){
				return null;
			}
		}
				
	}else if(window.XMLHttpRequest){
		return new XMLHttpRequest();
	}
};

//전역변수
var xmlHttp=null;
/*
 * 웹서버에 요청 전송하기
 */
function sendRequest(url,params,callback,method){
	//xmlHttp에 XMLHttpRequest 객체 저장.
	xmlHttp=getXMLRequest();
	
	//httpMethod : 'GET','POST','PUT'
	//HTTP 메서드 지정
	var httpMethod = method ? method : 'GET';
	if(httpMethod != 'GET' && httpMethod != 'POST'){
		httpMethod='GET';
	}
	
	var httpParams = (params == null || params == '')?
			null : params;
	
	//url은 요청하고자하는 서버의 url임.
	var httpUrl = url;
	if(httpMethod == 'GET' && httpParams != null){
		httpUrl = httpUrl + "?" + httpParams;
	}
	
	//open() : 웹서버에 요청을 전송하기.
	/*
	 * 1. HTTP 메서드 지정.
	 * 2. URL
	 * 3. 동기/비동기(true)
	 */
	
	xmlHttp.open(httpMethod,httpUrl,true);
	
	//void setRequestHeader(string header,string value)
	xmlHttp.setRequestHeader('Content-Type',
			'application/x-www-form-urlencoded');
	
	//자바스크립트 콜백함수를 저장함.
	xmlHttp.onreadystatechange = callback;	//콜백함수등록
	
	//void send(content)
	xmlHttp.send(httpMethod=='POST'?httpParams:null);
};
















