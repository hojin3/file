package com.sist.dao;

import java.io.*;
import java.util.*;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class DataBoardDAO {
	private static SqlSessionFactory ssf;
	static{	//static ������ �ʱ�ȭ
		try{
			Reader reader=Resources.getResourceAsReader("Config.xml");
			ssf=new SqlSessionFactoryBuilder().build(reader);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}
	
	public static List<DataBoardVO> databoardListData(Map map){
		List<DataBoardVO> list=new ArrayList<>();
		
		try{
			SqlSession session=ssf.openSession();
			list=session.selectList("databoardListData", map);
			session.close();
		}catch(Exception ex){
			ex.printStackTrace();
		}
		
		return list;
	}
}




















